const InitialStates = {}
export default InitialStates