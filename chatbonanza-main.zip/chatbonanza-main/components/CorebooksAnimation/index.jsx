import React, { Children} from "react";
import {
  getAnimationClass,
} from "./animations";
import "./CorebooksAnimation.css";
import styled from "styled-components";



const AnimationContainer = styled.div`
  & > * {
    transition-duration: ${(props) =>
      props.duration ? props.duration : "500ms"};
    transition-timing-function: ${(props) =>
      props.easing ? props.easing : "ease"};
  }
`;

const CorebooksAnimation = (props) => {
  const [_active, setActive] = React.useState(false);
  const { animationType, direction, active, easing, duration, children } =
    props;

 
  React.useEffect(()=>{
    if(active){
      setActive(false)
      setTimeout(()=>setActive(active),5);
    }
    
  },[children])
  return (
    <AnimationContainer
      className={`animation-container ${getAnimationClass(
        animationType,
        _active,
        Children.count(children) === 1,
        direction
      )}`}
      duration={duration}
      easing={easing}
    >
      {children}
    </AnimationContainer>
  );
};

export default CorebooksAnimation;
