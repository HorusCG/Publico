import React from 'react';
const MainComp = ({text, color}:{text: string, color: string})=><div style={{width:400, height: 400}}><h1 style={{ color}}>Hello world {text}</h1></div>

export default MainComp;