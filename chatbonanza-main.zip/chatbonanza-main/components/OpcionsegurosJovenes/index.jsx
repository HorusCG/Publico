import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import Rectangletwoo from 'Components/Rectangletwoo'
import Button from 'Components/Button'
import Rectanglefour from 'Components/Rectanglefour'
import './OpcionsegurosJovenes.css'





const OpcionsegurosJovenes = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['opcionsegurosjovenes']?.animationClass || {}}>

    <div id="id_foureight_twoofivesix" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } opcionsegurosjovenes ${ props.cssClass } ${ transaction['opcionsegurosjovenes']?.type ? transaction['opcionsegurosjovenes']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['opcionsegurosjovenes']?.duration, transitionTimingFunction: transaction['opcionsegurosjovenes']?.timingFunction }, ...props.style }} onClick={ props.OpcionsegurosJovenesonClick } onMouseEnter={ props.OpcionsegurosJovenesonMouseEnter } onMouseOver={ props.OpcionsegurosJovenesonMouseOver } onKeyPress={ props.OpcionsegurosJovenesonKeyPress } onDrag={ props.OpcionsegurosJovenesonDrag } onMouseLeave={ props.OpcionsegurosJovenesonMouseLeave } onMouseUp={ props.OpcionsegurosJovenesonMouseUp } onMouseDown={ props.OpcionsegurosJovenesonMouseDown } onKeyDown={ props.OpcionsegurosJovenesonKeyDown } onChange={ props.OpcionsegurosJovenesonChange } ondelay={ props.OpcionsegurosJovenesondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['framefour']?.animationClass || {}}>

          <div id="id_foureight_twoosixsix" className={` frame framefour ${ props.onClick ? 'cursor' : '' } ${ transaction['framefour']?.type ? transaction['framefour']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramefourStyle , transitionDuration: transaction['framefour']?.duration, transitionTimingFunction: transaction['framefour']?.timingFunction } } onClick={ props.FramefouronClick } onMouseEnter={ props.FramefouronMouseEnter } onMouseOver={ props.FramefouronMouseOver } onKeyPress={ props.FramefouronKeyPress } onDrag={ props.FramefouronDrag } onMouseLeave={ props.FramefouronMouseLeave } onMouseUp={ props.FramefouronMouseUp } onMouseDown={ props.FramefouronMouseDown } onKeyDown={ props.FramefouronKeyDown } onChange={ props.FramefouronChange } ondelay={ props.Framefourondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frameseven']?.animationClass || {}}>

              <div id="id_foureight_twoosixseven" className={` frame frameseven ${ props.onClick ? 'cursor' : '' } ${ transaction['frameseven']?.type ? transaction['frameseven']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramesevenStyle , transitionDuration: transaction['frameseven']?.duration, transitionTimingFunction: transaction['frameseven']?.timingFunction } } onClick={ props.FramesevenonClick } onMouseEnter={ props.FramesevenonMouseEnter } onMouseOver={ props.FramesevenonMouseOver } onKeyPress={ props.FramesevenonKeyPress } onDrag={ props.FramesevenonDrag } onMouseLeave={ props.FramesevenonMouseLeave } onMouseUp={ props.FramesevenonMouseUp } onMouseDown={ props.FramesevenonMouseDown } onKeyDown={ props.FramesevenonKeyDown } onChange={ props.FramesevenonChange } ondelay={ props.Framesevenondelay }>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['framefive']?.animationClass || {}}>

                  <div id="id_foureight_twoosixeight" className={` frame framefive ${ props.onClick ? 'cursor' : '' } ${ transaction['framefive']?.type ? transaction['framefive']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramefiveStyle , transitionDuration: transaction['framefive']?.duration, transitionTimingFunction: transaction['framefive']?.timingFunction } } onClick={ props.FramefiveonClick } onMouseEnter={ props.FramefiveonMouseEnter } onMouseOver={ props.FramefiveonMouseOver } onKeyPress={ props.FramefiveonKeyPress } onDrag={ props.FramefiveonDrag } onMouseLeave={ props.FramefiveonMouseLeave } onMouseUp={ props.FramefiveonMouseUp } onMouseDown={ props.FramefiveonMouseDown } onKeyDown={ props.FramefiveonKeyDown } onChange={ props.FramefiveonChange } ondelay={ props.Framefiveondelay }>
                    <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imageone']?.animationClass || {}}>
                      <img id="id_foureight_twoosixnigth" className={` rectangle imageone ${ props.onClick ? 'cursor' : '' } ${ transaction['imageone']?.type ? transaction['imageone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImageoneStyle , transitionDuration: transaction['imageone']?.duration, transitionTimingFunction: transaction['imageone']?.timingFunction }} onClick={ props.ImageoneonClick } onMouseEnter={ props.ImageoneonMouseEnter } onMouseOver={ props.ImageoneonMouseOver } onKeyPress={ props.ImageoneonKeyPress } onDrag={ props.ImageoneonDrag } onMouseLeave={ props.ImageoneonMouseLeave } onMouseUp={ props.ImageoneonMouseUp } onMouseDown={ props.ImageoneonMouseDown } onKeyDown={ props.ImageoneonKeyDown } onChange={ props.ImageoneonChange } ondelay={ props.Imageoneondelay } src={props.Imageone0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/2b3879adf412db478c331faeee5f712f385b76d1.png" } />
                    </CSSTransition>
                  </div>

                </CSSTransition>
              </div>

            </CSSTransition>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frameoneone']?.animationClass || {}}>

              <div id="id_foureight_twoosevenzero" className={` frame frameoneone ${ props.onClick ? 'cursor' : '' } ${ transaction['frameoneone']?.type ? transaction['frameoneone']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrameoneoneStyle , transitionDuration: transaction['frameoneone']?.duration, transitionTimingFunction: transaction['frameoneone']?.timingFunction } } onClick={ props.FrameoneoneonClick } onMouseEnter={ props.FrameoneoneonMouseEnter } onMouseOver={ props.FrameoneoneonMouseOver } onKeyPress={ props.FrameoneoneonKeyPress } onDrag={ props.FrameoneoneonDrag } onMouseLeave={ props.FrameoneoneonMouseLeave } onMouseUp={ props.FrameoneoneonMouseUp } onMouseDown={ props.FrameoneoneonMouseDown } onKeyDown={ props.FrameoneoneonKeyDown } onChange={ props.FrameoneoneonChange } ondelay={ props.Frameoneoneondelay }>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.animationClass || {}}>

                  <div id="id_onezerozero_sevensixfour" className={` frame imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.timingFunction } } onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeondelay }>
                    <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.animationClass || {}}>
                      <img id="id_onezerozero_sevensixfive" className={` rectangle imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.timingFunction }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeondelay } src={props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/e59c03e3ad6cd99062c4391243b9c7e2c3c47b6e.png" } />
                    </CSSTransition>
                  </div>

                </CSSTransition>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frameonefour']?.animationClass || {}}>

                  <div id="id_foureight_twooseventwoo" className={` frame frameonefour ${ props.onClick ? 'cursor' : '' } ${ transaction['frameonefour']?.type ? transaction['frameonefour']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrameonefourStyle , transitionDuration: transaction['frameonefour']?.duration, transitionTimingFunction: transaction['frameonefour']?.timingFunction } } onClick={ props.FrameonefouronClick } onMouseEnter={ props.FrameonefouronMouseEnter } onMouseOver={ props.FrameonefouronMouseOver } onKeyPress={ props.FrameonefouronKeyPress } onDrag={ props.FrameonefouronDrag } onMouseLeave={ props.FrameonefouronMouseLeave } onMouseUp={ props.FrameonefouronMouseUp } onMouseDown={ props.FrameonefouronMouseDown } onKeyDown={ props.FrameonefouronKeyDown } onChange={ props.FrameonefouronChange } ondelay={ props.Frameonefourondelay }>
                    <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglefour']?.animationClass || {}}>
                      <Rectanglefour { ...{ ...props, style:false } } HolaminombreesErickyyosertuasesorduranteesterecorrido0={ props.HolaminombreesErickyyosertuasesorduranteesterecorrido0 || "Que tipo de seguro es el que estas buscando?" } cssClass={"C_foureight_twooseventhree "}  />
    </CSSTransition >
                    </div>
               
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['framesix']?.animationClass || {}}
    >
    
                    <div id="id_sixthree_twoofourthree" className={` frame framesix ${ props.onClick ? 'cursor' : '' } ${ transaction['framesix']?.type ? transaction['framesix']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramesixStyle , transitionDuration: transaction['framesix']?.duration, transitionTimingFunction: transaction['framesix']?.timingFunction } } onClick={ props.FramesixonClick } onMouseEnter={ props.FramesixonMouseEnter } onMouseOver={ props.FramesixonMouseOver } onKeyPress={ props.FramesixonKeyPress } onDrag={ props.FramesixonDrag } onMouseLeave={ props.FramesixonMouseLeave } onMouseUp={ props.FramesixonMouseUp } onMouseDown={ props.FramesixonMouseDown } onKeyDown={ props.FramesixonKeyDown } onChange={ props.FramesixonChange } ondelay={ props.Framesixondelay }>
                        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['button']?.animationClass || {}}>
                          <Button { ...{ ...props, style:false } } cssClass={"C_onezerozero_eightfourzero "}  />
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['button']?.animationClass || {}}
    >
    <Button { ...{ ...props, style:false } }    cssClass={" C_sixthree_threesixnigth "}  />
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['button']?.animationClass || {}}
    >
    <Button { ...{ ...props, style:false } }    cssClass={" C_sixthree_fourthreeseven "}  />
    </CSSTransition >
                    </div>
               
    </CSSTransition >
                    </div>
               
    </CSSTransition >
                    </div>
               
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['cuadrodetexto']?.animationClass || {}}
    >
    
                    <div id="id_foureight_twoosevenfive" className={` frame cuadrodetexto ${ props.onClick ? 'cursor' : '' } ${ transaction['cuadrodetexto']?.type ? transaction['cuadrodetexto']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.CuadrodetextoStyle , transitionDuration: transaction['cuadrodetexto']?.duration, transitionTimingFunction: transaction['cuadrodetexto']?.timingFunction } } onClick={ props.CuadrodetextoonClick } onMouseEnter={ props.CuadrodetextoonMouseEnter } onMouseOver={ props.CuadrodetextoonMouseOver } onKeyPress={ props.CuadrodetextoonKeyPress } onDrag={ props.CuadrodetextoonDrag } onMouseLeave={ props.CuadrodetextoonMouseLeave } onMouseUp={ props.CuadrodetextoonMouseUp } onMouseDown={ props.CuadrodetextoonMouseDown } onKeyDown={ props.CuadrodetextoonKeyDown } onChange={ props.CuadrodetextoonChange } ondelay={ props.Cuadrodetextoondelay }>
                            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectangletwoo']?.animationClass || {}}>
                              <Rectangletwoo { ...{ ...props, style:false } } Ingresartexto0={ props.Ingresartexto0 || "Ingresar texto" } cssClass={"C_foureight_twoosevensix "}  />
    </CSSTransition >
                    </div>
               
    </CSSTransition >
            
            </>
        }
        </div>
    
    </CSSTransition >
            </>
        
    ) 
}

OpcionsegurosJovenes.propTypes = {
    style: PropTypes.any,
Imageone0: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree0: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorrido0: PropTypes.any,
Ingresartexto0: PropTypes.any,
OpcionsegurosJovenesonClick: PropTypes.any,
OpcionsegurosJovenesonMouseEnter: PropTypes.any,
OpcionsegurosJovenesonMouseOver: PropTypes.any,
OpcionsegurosJovenesonKeyPress: PropTypes.any,
OpcionsegurosJovenesonDrag: PropTypes.any,
OpcionsegurosJovenesonMouseLeave: PropTypes.any,
OpcionsegurosJovenesonMouseUp: PropTypes.any,
OpcionsegurosJovenesonMouseDown: PropTypes.any,
OpcionsegurosJovenesonKeyDown: PropTypes.any,
OpcionsegurosJovenesonChange: PropTypes.any,
OpcionsegurosJovenesondelay: PropTypes.any,
FramefouronClick: PropTypes.any,
FramefouronMouseEnter: PropTypes.any,
FramefouronMouseOver: PropTypes.any,
FramefouronKeyPress: PropTypes.any,
FramefouronDrag: PropTypes.any,
FramefouronMouseLeave: PropTypes.any,
FramefouronMouseUp: PropTypes.any,
FramefouronMouseDown: PropTypes.any,
FramefouronKeyDown: PropTypes.any,
FramefouronChange: PropTypes.any,
Framefourondelay: PropTypes.any,
FramesevenonClick: PropTypes.any,
FramesevenonMouseEnter: PropTypes.any,
FramesevenonMouseOver: PropTypes.any,
FramesevenonKeyPress: PropTypes.any,
FramesevenonDrag: PropTypes.any,
FramesevenonMouseLeave: PropTypes.any,
FramesevenonMouseUp: PropTypes.any,
FramesevenonMouseDown: PropTypes.any,
FramesevenonKeyDown: PropTypes.any,
FramesevenonChange: PropTypes.any,
Framesevenondelay: PropTypes.any,
FramefiveonClick: PropTypes.any,
FramefiveonMouseEnter: PropTypes.any,
FramefiveonMouseOver: PropTypes.any,
FramefiveonKeyPress: PropTypes.any,
FramefiveonDrag: PropTypes.any,
FramefiveonMouseLeave: PropTypes.any,
FramefiveonMouseUp: PropTypes.any,
FramefiveonMouseDown: PropTypes.any,
FramefiveonKeyDown: PropTypes.any,
FramefiveonChange: PropTypes.any,
Framefiveondelay: PropTypes.any,
ImageoneonClick: PropTypes.any,
ImageoneonMouseEnter: PropTypes.any,
ImageoneonMouseOver: PropTypes.any,
ImageoneonKeyPress: PropTypes.any,
ImageoneonDrag: PropTypes.any,
ImageoneonMouseLeave: PropTypes.any,
ImageoneonMouseUp: PropTypes.any,
ImageoneonMouseDown: PropTypes.any,
ImageoneonKeyDown: PropTypes.any,
ImageoneonChange: PropTypes.any,
Imageoneondelay: PropTypes.any,
FrameoneoneonClick: PropTypes.any,
FrameoneoneonMouseEnter: PropTypes.any,
FrameoneoneonMouseOver: PropTypes.any,
FrameoneoneonKeyPress: PropTypes.any,
FrameoneoneonDrag: PropTypes.any,
FrameoneoneonMouseLeave: PropTypes.any,
FrameoneoneonMouseUp: PropTypes.any,
FrameoneoneonMouseDown: PropTypes.any,
FrameoneoneonKeyDown: PropTypes.any,
FrameoneoneonChange: PropTypes.any,
Frameoneoneondelay: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonClick: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseEnter: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseOver: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyPress: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonDrag: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseLeave: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseUp: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonChange: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeondelay: PropTypes.any,
FrameonefouronClick: PropTypes.any,
FrameonefouronMouseEnter: PropTypes.any,
FrameonefouronMouseOver: PropTypes.any,
FrameonefouronKeyPress: PropTypes.any,
FrameonefouronDrag: PropTypes.any,
FrameonefouronMouseLeave: PropTypes.any,
FrameonefouronMouseUp: PropTypes.any,
FrameonefouronMouseDown: PropTypes.any,
FrameonefouronKeyDown: PropTypes.any,
FrameonefouronChange: PropTypes.any,
Frameonefourondelay: PropTypes.any,
FramesixonClick: PropTypes.any,
FramesixonMouseEnter: PropTypes.any,
FramesixonMouseOver: PropTypes.any,
FramesixonKeyPress: PropTypes.any,
FramesixonDrag: PropTypes.any,
FramesixonMouseLeave: PropTypes.any,
FramesixonMouseUp: PropTypes.any,
FramesixonMouseDown: PropTypes.any,
FramesixonKeyDown: PropTypes.any,
FramesixonChange: PropTypes.any,
Framesixondelay: PropTypes.any,
CuadrodetextoonClick: PropTypes.any,
CuadrodetextoonMouseEnter: PropTypes.any,
CuadrodetextoonMouseOver: PropTypes.any,
CuadrodetextoonKeyPress: PropTypes.any,
CuadrodetextoonDrag: PropTypes.any,
CuadrodetextoonMouseLeave: PropTypes.any,
CuadrodetextoonMouseUp: PropTypes.any,
CuadrodetextoonMouseDown: PropTypes.any,
CuadrodetextoonKeyDown: PropTypes.any,
CuadrodetextoonChange: PropTypes.any,
Cuadrodetextoondelay: PropTypes.any
}
export default OpcionsegurosJovenes;