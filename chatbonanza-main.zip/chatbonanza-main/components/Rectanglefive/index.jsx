import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Rectanglefive.css'





const Rectanglefive = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglefive']?.animationClass || {}}>

    <div id="id_sixtwoo_twoozeroseven" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } rectanglefive C_sixtwoo_twoozeroseven ${ props.cssClass } ${ transaction['rectanglefive']?.type ? transaction['rectanglefive']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['rectanglefive']?.duration, transitionTimingFunction: transaction['rectanglefive']?.timingFunction }, ...props.style }} onClick={ props.RectanglefiveonClick } onMouseEnter={ props.RectanglefiveonMouseEnter } onMouseOver={ props.RectanglefiveonMouseOver } onKeyPress={ props.RectanglefiveonKeyPress } onDrag={ props.RectanglefiveonDrag } onMouseLeave={ props.RectanglefiveonMouseLeave } onMouseUp={ props.RectanglefiveonMouseUp } onMouseDown={ props.RectanglefiveonMouseDown } onKeyDown={ props.RectanglefiveonKeyDown } onChange={ props.RectanglefiveonChange } ondelay={ props.Rectanglefiveondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglefive']?.animationClass || {}}>
          <div id="id_sixtwoo_twoozerosix" className={` rectangle rectanglefive ${ props.onClick ? 'cursor' : '' } ${ transaction['rectanglefive']?.type ? transaction['rectanglefive']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.RectanglefiveStyle , transitionDuration: transaction['rectanglefive']?.duration, transitionTimingFunction: transaction['rectanglefive']?.timingFunction }} onClick={ props.RectanglefiveonClick } onMouseEnter={ props.RectanglefiveonMouseEnter } onMouseOver={ props.RectanglefiveonMouseOver } onKeyPress={ props.RectanglefiveonKeyPress } onDrag={ props.RectanglefiveonDrag } onMouseLeave={ props.RectanglefiveonMouseLeave } onMouseUp={ props.RectanglefiveonMouseUp } onMouseDown={ props.RectanglefiveonMouseDown } onKeyDown={ props.RectanglefiveonKeyDown } onChange={ props.RectanglefiveonChange } ondelay={ props.Rectanglefiveondelay }></div>
        </CSSTransition>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['ingresatuedad']?.animationClass || {}}>

          <span id="id_sixtwoo_twoozeroeight"  className={` text ingresatuedad    ${ props.onClick ? 'cursor' : ''}  ${ transaction['ingresatuedad']?.type ? transaction['ingresatuedad']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.IngresatuedadStyle , transitionDuration: transaction['ingresatuedad']?.duration, transitionTimingFunction: transaction['ingresatuedad']?.timingFunction }} onClick={ props.IngresatuedadonClick } onMouseEnter={ props.IngresatuedadonMouseEnter } onMouseOver={ props.IngresatuedadonMouseOver } onKeyPress={ props.IngresatuedadonKeyPress } onDrag={ props.IngresatuedadonDrag } onMouseLeave={ props.IngresatuedadonMouseLeave } onMouseUp={ props.IngresatuedadonMouseUp } onMouseDown={ props.IngresatuedadonMouseDown } onKeyDown={ props.IngresatuedadonKeyDown } onChange={ props.IngresatuedadonChange } ondelay={ props.Ingresatuedadondelay } >{props.Ingresatuedad0 || `Ingresa tu edad`}</span>

        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Rectanglefive.propTypes = {
    style: PropTypes.any,
Rectanglefive0: PropTypes.any,
Ingresatuedad0: PropTypes.any,
RectanglefiveonClick: PropTypes.any,
RectanglefiveonMouseEnter: PropTypes.any,
RectanglefiveonMouseOver: PropTypes.any,
RectanglefiveonKeyPress: PropTypes.any,
RectanglefiveonDrag: PropTypes.any,
RectanglefiveonMouseLeave: PropTypes.any,
RectanglefiveonMouseUp: PropTypes.any,
RectanglefiveonMouseDown: PropTypes.any,
RectanglefiveonKeyDown: PropTypes.any,
RectanglefiveonChange: PropTypes.any,
Rectanglefiveondelay: PropTypes.any,
IngresatuedadonClick: PropTypes.any,
IngresatuedadonMouseEnter: PropTypes.any,
IngresatuedadonMouseOver: PropTypes.any,
IngresatuedadonKeyPress: PropTypes.any,
IngresatuedadonDrag: PropTypes.any,
IngresatuedadonMouseLeave: PropTypes.any,
IngresatuedadonMouseUp: PropTypes.any,
IngresatuedadonMouseDown: PropTypes.any,
IngresatuedadonKeyDown: PropTypes.any,
IngresatuedadonChange: PropTypes.any,
Ingresatuedadondelay: PropTypes.any
}
export default Rectanglefive;