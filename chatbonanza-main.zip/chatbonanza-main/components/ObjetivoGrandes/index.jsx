import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import Rectangletwoo from 'Components/Rectangletwoo'
import Rectanglefour from 'Components/Rectanglefour'
import './ObjetivoGrandes.css'





const ObjetivoGrandes = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['objetivograndes']?.animationClass || {}}>

    <div id="id_foureight_twootwoosix" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } objetivograndes ${ props.cssClass } ${ transaction['objetivograndes']?.type ? transaction['objetivograndes']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['objetivograndes']?.duration, transitionTimingFunction: transaction['objetivograndes']?.timingFunction }, ...props.style }} onClick={ props.ObjetivoGrandesonClick } onMouseEnter={ props.ObjetivoGrandesonMouseEnter } onMouseOver={ props.ObjetivoGrandesonMouseOver } onKeyPress={ props.ObjetivoGrandesonKeyPress } onDrag={ props.ObjetivoGrandesonDrag } onMouseLeave={ props.ObjetivoGrandesonMouseLeave } onMouseUp={ props.ObjetivoGrandesonMouseUp } onMouseDown={ props.ObjetivoGrandesonMouseDown } onKeyDown={ props.ObjetivoGrandesonKeyDown } onChange={ props.ObjetivoGrandesonChange } ondelay={ props.ObjetivoGrandesondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['framefour']?.animationClass || {}}>

          <div id="id_foureight_twoothreesix" className={` frame framefour ${ props.onClick ? 'cursor' : '' } ${ transaction['framefour']?.type ? transaction['framefour']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramefourStyle , transitionDuration: transaction['framefour']?.duration, transitionTimingFunction: transaction['framefour']?.timingFunction } } onClick={ props.FramefouronClick } onMouseEnter={ props.FramefouronMouseEnter } onMouseOver={ props.FramefouronMouseOver } onKeyPress={ props.FramefouronKeyPress } onDrag={ props.FramefouronDrag } onMouseLeave={ props.FramefouronMouseLeave } onMouseUp={ props.FramefouronMouseUp } onMouseDown={ props.FramefouronMouseDown } onKeyDown={ props.FramefouronKeyDown } onChange={ props.FramefouronChange } ondelay={ props.Framefourondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frameseven']?.animationClass || {}}>

              <div id="id_foureight_twoothreeseven" className={` frame frameseven ${ props.onClick ? 'cursor' : '' } ${ transaction['frameseven']?.type ? transaction['frameseven']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramesevenStyle , transitionDuration: transaction['frameseven']?.duration, transitionTimingFunction: transaction['frameseven']?.timingFunction } } onClick={ props.FramesevenonClick } onMouseEnter={ props.FramesevenonMouseEnter } onMouseOver={ props.FramesevenonMouseOver } onKeyPress={ props.FramesevenonKeyPress } onDrag={ props.FramesevenonDrag } onMouseLeave={ props.FramesevenonMouseLeave } onMouseUp={ props.FramesevenonMouseUp } onMouseDown={ props.FramesevenonMouseDown } onKeyDown={ props.FramesevenonKeyDown } onChange={ props.FramesevenonChange } ondelay={ props.Framesevenondelay }>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['framefive']?.animationClass || {}}>

                  <div id="id_foureight_twoothreeeight" className={` frame framefive ${ props.onClick ? 'cursor' : '' } ${ transaction['framefive']?.type ? transaction['framefive']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramefiveStyle , transitionDuration: transaction['framefive']?.duration, transitionTimingFunction: transaction['framefive']?.timingFunction } } onClick={ props.FramefiveonClick } onMouseEnter={ props.FramefiveonMouseEnter } onMouseOver={ props.FramefiveonMouseOver } onKeyPress={ props.FramefiveonKeyPress } onDrag={ props.FramefiveonDrag } onMouseLeave={ props.FramefiveonMouseLeave } onMouseUp={ props.FramefiveonMouseUp } onMouseDown={ props.FramefiveonMouseDown } onKeyDown={ props.FramefiveonKeyDown } onChange={ props.FramefiveonChange } ondelay={ props.Framefiveondelay }>
                    <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imageone']?.animationClass || {}}>
                      <img id="id_foureight_twoothreenigth" className={` rectangle imageone ${ props.onClick ? 'cursor' : '' } ${ transaction['imageone']?.type ? transaction['imageone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImageoneStyle , transitionDuration: transaction['imageone']?.duration, transitionTimingFunction: transaction['imageone']?.timingFunction }} onClick={ props.ImageoneonClick } onMouseEnter={ props.ImageoneonMouseEnter } onMouseOver={ props.ImageoneonMouseOver } onKeyPress={ props.ImageoneonKeyPress } onDrag={ props.ImageoneonDrag } onMouseLeave={ props.ImageoneonMouseLeave } onMouseUp={ props.ImageoneonMouseUp } onMouseDown={ props.ImageoneonMouseDown } onKeyDown={ props.ImageoneonKeyDown } onChange={ props.ImageoneonChange } ondelay={ props.Imageoneondelay } src={props.Imageone0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/2b3879adf412db478c331faeee5f712f385b76d1.png" } />
                    </CSSTransition>
                  </div>

                </CSSTransition>
              </div>

            </CSSTransition>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frameoneone']?.animationClass || {}}>

              <div id="id_foureight_twoofourzero" className={` frame frameoneone ${ props.onClick ? 'cursor' : '' } ${ transaction['frameoneone']?.type ? transaction['frameoneone']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrameoneoneStyle , transitionDuration: transaction['frameoneone']?.duration, transitionTimingFunction: transaction['frameoneone']?.timingFunction } } onClick={ props.FrameoneoneonClick } onMouseEnter={ props.FrameoneoneonMouseEnter } onMouseOver={ props.FrameoneoneonMouseOver } onKeyPress={ props.FrameoneoneonKeyPress } onDrag={ props.FrameoneoneonDrag } onMouseLeave={ props.FrameoneoneonMouseLeave } onMouseUp={ props.FrameoneoneonMouseUp } onMouseDown={ props.FrameoneoneonMouseDown } onKeyDown={ props.FrameoneoneonKeyDown } onChange={ props.FrameoneoneonChange } ondelay={ props.Frameoneoneondelay }>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwoo']?.animationClass || {}}>
                  <img id="id_foureight_twoofivefive" className={` rectangle imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwoo ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwoo']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwoo']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwoo']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwoo']?.timingFunction }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooondelay } src={props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwoo0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/14e49ff30b9feb8e248b346f5c98144e629be70f.png" } />
                </CSSTransition>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frameonefour']?.animationClass || {}}>

                  <div id="id_foureight_twoofourtwoo" className={` frame frameonefour ${ props.onClick ? 'cursor' : '' } ${ transaction['frameonefour']?.type ? transaction['frameonefour']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrameonefourStyle , transitionDuration: transaction['frameonefour']?.duration, transitionTimingFunction: transaction['frameonefour']?.timingFunction } } onClick={ props.FrameonefouronClick } onMouseEnter={ props.FrameonefouronMouseEnter } onMouseOver={ props.FrameonefouronMouseOver } onKeyPress={ props.FrameonefouronKeyPress } onDrag={ props.FrameonefouronDrag } onMouseLeave={ props.FrameonefouronMouseLeave } onMouseUp={ props.FrameonefouronMouseUp } onMouseDown={ props.FrameonefouronMouseDown } onKeyDown={ props.FrameonefouronKeyDown } onChange={ props.FrameonefouronChange } ondelay={ props.Frameonefourondelay }>
                    <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglefour']?.animationClass || {}}>
                      <Rectanglefour { ...{ ...props, style:false } } HolaminombreesErickyyosertuasesorduranteesterecorrido0={ props.HolaminombreesErickyyosertuasesorduranteesterecorrido0 || "¿Cual es tu objetivo? ¿Para que es lo que quieres ahorrar?" } cssClass={"C_foureight_twoofourthree "}  />
    </CSSTransition >
                    </div>
               
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['frameonetwoo']?.animationClass || {}}
    >
    
                    <div id="id_foureight_twoofourfour" className={` frame frameonetwoo ${ props.onClick ? 'cursor' : '' } ${ transaction['frameonetwoo']?.type ? transaction['frameonetwoo']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrameonetwooStyle , transitionDuration: transaction['frameonetwoo']?.duration, transitionTimingFunction: transaction['frameonetwoo']?.timingFunction } } onClick={ props.FrameonetwooonClick } onMouseEnter={ props.FrameonetwooonMouseEnter } onMouseOver={ props.FrameonetwooonMouseOver } onKeyPress={ props.FrameonetwooonKeyPress } onDrag={ props.FrameonetwooonDrag } onMouseLeave={ props.FrameonetwooonMouseLeave } onMouseUp={ props.FrameonetwooonMouseUp } onMouseDown={ props.FrameonetwooonMouseDown } onKeyDown={ props.FrameonetwooonKeyDown } onChange={ props.FrameonetwooonChange } ondelay={ props.Frameonetwooondelay }>

                  </div>

                </CSSTransition>
              </div>

            </CSSTransition>
          </div>

        </CSSTransition>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['cuadrodetexto']?.animationClass || {}}>

          <div id="id_foureight_twoofourfive" className={` frame cuadrodetexto ${ props.onClick ? 'cursor' : '' } ${ transaction['cuadrodetexto']?.type ? transaction['cuadrodetexto']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.CuadrodetextoStyle , transitionDuration: transaction['cuadrodetexto']?.duration, transitionTimingFunction: transaction['cuadrodetexto']?.timingFunction } } onClick={ props.CuadrodetextoonClick } onMouseEnter={ props.CuadrodetextoonMouseEnter } onMouseOver={ props.CuadrodetextoonMouseOver } onKeyPress={ props.CuadrodetextoonKeyPress } onDrag={ props.CuadrodetextoonDrag } onMouseLeave={ props.CuadrodetextoonMouseLeave } onMouseUp={ props.CuadrodetextoonMouseUp } onMouseDown={ props.CuadrodetextoonMouseDown } onKeyDown={ props.CuadrodetextoonKeyDown } onChange={ props.CuadrodetextoonChange } ondelay={ props.Cuadrodetextoondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectangletwoo']?.animationClass || {}}>
              <Rectangletwoo { ...{ ...props, style:false } } cssClass={"C_foureight_threesixfive "}  />
    </CSSTransition >
                    </div>
               
    </CSSTransition >
            
            </>
        }
        </div>
    
    </CSSTransition >
            </>
        
    ) 
}

ObjetivoGrandes.propTypes = {
    style: PropTypes.any,
Imageone0: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwoo0: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorrido0: PropTypes.any,
ObjetivoGrandesonClick: PropTypes.any,
ObjetivoGrandesonMouseEnter: PropTypes.any,
ObjetivoGrandesonMouseOver: PropTypes.any,
ObjetivoGrandesonKeyPress: PropTypes.any,
ObjetivoGrandesonDrag: PropTypes.any,
ObjetivoGrandesonMouseLeave: PropTypes.any,
ObjetivoGrandesonMouseUp: PropTypes.any,
ObjetivoGrandesonMouseDown: PropTypes.any,
ObjetivoGrandesonKeyDown: PropTypes.any,
ObjetivoGrandesonChange: PropTypes.any,
ObjetivoGrandesondelay: PropTypes.any,
FramefouronClick: PropTypes.any,
FramefouronMouseEnter: PropTypes.any,
FramefouronMouseOver: PropTypes.any,
FramefouronKeyPress: PropTypes.any,
FramefouronDrag: PropTypes.any,
FramefouronMouseLeave: PropTypes.any,
FramefouronMouseUp: PropTypes.any,
FramefouronMouseDown: PropTypes.any,
FramefouronKeyDown: PropTypes.any,
FramefouronChange: PropTypes.any,
Framefourondelay: PropTypes.any,
FramesevenonClick: PropTypes.any,
FramesevenonMouseEnter: PropTypes.any,
FramesevenonMouseOver: PropTypes.any,
FramesevenonKeyPress: PropTypes.any,
FramesevenonDrag: PropTypes.any,
FramesevenonMouseLeave: PropTypes.any,
FramesevenonMouseUp: PropTypes.any,
FramesevenonMouseDown: PropTypes.any,
FramesevenonKeyDown: PropTypes.any,
FramesevenonChange: PropTypes.any,
Framesevenondelay: PropTypes.any,
FramefiveonClick: PropTypes.any,
FramefiveonMouseEnter: PropTypes.any,
FramefiveonMouseOver: PropTypes.any,
FramefiveonKeyPress: PropTypes.any,
FramefiveonDrag: PropTypes.any,
FramefiveonMouseLeave: PropTypes.any,
FramefiveonMouseUp: PropTypes.any,
FramefiveonMouseDown: PropTypes.any,
FramefiveonKeyDown: PropTypes.any,
FramefiveonChange: PropTypes.any,
Framefiveondelay: PropTypes.any,
ImageoneonClick: PropTypes.any,
ImageoneonMouseEnter: PropTypes.any,
ImageoneonMouseOver: PropTypes.any,
ImageoneonKeyPress: PropTypes.any,
ImageoneonDrag: PropTypes.any,
ImageoneonMouseLeave: PropTypes.any,
ImageoneonMouseUp: PropTypes.any,
ImageoneonMouseDown: PropTypes.any,
ImageoneonKeyDown: PropTypes.any,
ImageoneonChange: PropTypes.any,
Imageoneondelay: PropTypes.any,
FrameoneoneonClick: PropTypes.any,
FrameoneoneonMouseEnter: PropTypes.any,
FrameoneoneonMouseOver: PropTypes.any,
FrameoneoneonKeyPress: PropTypes.any,
FrameoneoneonDrag: PropTypes.any,
FrameoneoneonMouseLeave: PropTypes.any,
FrameoneoneonMouseUp: PropTypes.any,
FrameoneoneonMouseDown: PropTypes.any,
FrameoneoneonKeyDown: PropTypes.any,
FrameoneoneonChange: PropTypes.any,
Frameoneoneondelay: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonClick: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseEnter: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseOver: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonKeyPress: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonDrag: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseLeave: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseUp: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonMouseDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonKeyDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooonChange: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofivetwooondelay: PropTypes.any,
FrameonefouronClick: PropTypes.any,
FrameonefouronMouseEnter: PropTypes.any,
FrameonefouronMouseOver: PropTypes.any,
FrameonefouronKeyPress: PropTypes.any,
FrameonefouronDrag: PropTypes.any,
FrameonefouronMouseLeave: PropTypes.any,
FrameonefouronMouseUp: PropTypes.any,
FrameonefouronMouseDown: PropTypes.any,
FrameonefouronKeyDown: PropTypes.any,
FrameonefouronChange: PropTypes.any,
Frameonefourondelay: PropTypes.any,
FrameonetwooonClick: PropTypes.any,
FrameonetwooonMouseEnter: PropTypes.any,
FrameonetwooonMouseOver: PropTypes.any,
FrameonetwooonKeyPress: PropTypes.any,
FrameonetwooonDrag: PropTypes.any,
FrameonetwooonMouseLeave: PropTypes.any,
FrameonetwooonMouseUp: PropTypes.any,
FrameonetwooonMouseDown: PropTypes.any,
FrameonetwooonKeyDown: PropTypes.any,
FrameonetwooonChange: PropTypes.any,
Frameonetwooondelay: PropTypes.any,
CuadrodetextoonClick: PropTypes.any,
CuadrodetextoonMouseEnter: PropTypes.any,
CuadrodetextoonMouseOver: PropTypes.any,
CuadrodetextoonKeyPress: PropTypes.any,
CuadrodetextoonDrag: PropTypes.any,
CuadrodetextoonMouseLeave: PropTypes.any,
CuadrodetextoonMouseUp: PropTypes.any,
CuadrodetextoonMouseDown: PropTypes.any,
CuadrodetextoonKeyDown: PropTypes.any,
CuadrodetextoonChange: PropTypes.any,
Cuadrodetextoondelay: PropTypes.any
}
export default ObjetivoGrandes;