import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree.css'





const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.animationClass || {}}>

    <div id="id_onezerozero_nigtheighteight" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree C_onezerozero_nigtheighteight ${ props.cssClass } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.timingFunction }, ...props.style }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.animationClass || {}}>

          <div id="id_onezerozero_nigtheightnigth" className={` frame imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.timingFunction } } onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.animationClass || {}}>
              <img id="id_onezerozero_nigthnigthzero" className={` rectangle imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree']?.timingFunction }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeondelay } src={props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/e59c03e3ad6cd99062c4391243b9c7e2c3c47b6e.png" } />
            </CSSTransition>
          </div>

        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree.propTypes = {
    style: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree0: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonClick: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseEnter: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseOver: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyPress: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonDrag: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseLeave: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseUp: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonChange: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeondelay: PropTypes.any
}
export default ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree;