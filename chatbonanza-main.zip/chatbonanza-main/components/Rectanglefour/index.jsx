import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Rectanglefour.css'





const Rectanglefour = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglefour']?.animationClass || {}}>

    <div id="id_onezerozero_onezerosixfive" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } rectanglefour C_onezerozero_onezerosixfive ${ props.cssClass } ${ transaction['rectanglefour']?.type ? transaction['rectanglefour']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['rectanglefour']?.duration, transitionTimingFunction: transaction['rectanglefour']?.timingFunction }, ...props.style }} onClick={ props.RectanglefouronClick } onMouseEnter={ props.RectanglefouronMouseEnter } onMouseOver={ props.RectanglefouronMouseOver } onKeyPress={ props.RectanglefouronKeyPress } onDrag={ props.RectanglefouronDrag } onMouseLeave={ props.RectanglefouronMouseLeave } onMouseUp={ props.RectanglefouronMouseUp } onMouseDown={ props.RectanglefouronMouseDown } onKeyDown={ props.RectanglefouronKeyDown } onChange={ props.RectanglefouronChange } ondelay={ props.Rectanglefourondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglefour']?.animationClass || {}}>

          <div id="id_onezerozero_onezerosixsix" className={` frame rectanglefour ${ props.onClick ? 'cursor' : '' } ${ transaction['rectanglefour']?.type ? transaction['rectanglefour']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.RectanglefourStyle , transitionDuration: transaction['rectanglefour']?.duration, transitionTimingFunction: transaction['rectanglefour']?.timingFunction } } onClick={ props.RectanglefouronClick } onMouseEnter={ props.RectanglefouronMouseEnter } onMouseOver={ props.RectanglefouronMouseOver } onKeyPress={ props.RectanglefouronKeyPress } onDrag={ props.RectanglefouronDrag } onMouseLeave={ props.RectanglefouronMouseLeave } onMouseUp={ props.RectanglefouronMouseUp } onMouseDown={ props.RectanglefouronMouseDown } onKeyDown={ props.RectanglefouronKeyDown } onChange={ props.RectanglefouronChange } ondelay={ props.Rectanglefourondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglefour']?.animationClass || {}}>
              <div id="id_onezerozero_onezerosixseven" className={` rectangle rectanglefour ${ props.onClick ? 'cursor' : '' } ${ transaction['rectanglefour']?.type ? transaction['rectanglefour']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.RectanglefourStyle , transitionDuration: transaction['rectanglefour']?.duration, transitionTimingFunction: transaction['rectanglefour']?.timingFunction }} onClick={ props.RectanglefouronClick } onMouseEnter={ props.RectanglefouronMouseEnter } onMouseOver={ props.RectanglefouronMouseOver } onKeyPress={ props.RectanglefouronKeyPress } onDrag={ props.RectanglefouronDrag } onMouseLeave={ props.RectanglefouronMouseLeave } onMouseUp={ props.RectanglefouronMouseUp } onMouseDown={ props.RectanglefouronMouseDown } onKeyDown={ props.RectanglefouronKeyDown } onChange={ props.RectanglefouronChange } ondelay={ props.Rectanglefourondelay }></div>
            </CSSTransition>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['holaminombreeserickyyosertuasesorduranteesterecorrido']?.animationClass || {}}>

              <span id="id_onezerozero_onezerosixeight"  className={` text holaminombreeserickyyosertuasesorduranteesterecorrido    ${ props.onClick ? 'cursor' : ''}  ${ transaction['holaminombreeserickyyosertuasesorduranteesterecorrido']?.type ? transaction['holaminombreeserickyyosertuasesorduranteesterecorrido']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.HolaminombreesErickyyosertuasesorduranteesterecorridoStyle , transitionDuration: transaction['holaminombreeserickyyosertuasesorduranteesterecorrido']?.duration, transitionTimingFunction: transaction['holaminombreeserickyyosertuasesorduranteesterecorrido']?.timingFunction }} onClick={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonClick } onMouseEnter={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseEnter } onMouseOver={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseOver } onKeyPress={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonKeyPress } onDrag={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonDrag } onMouseLeave={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseLeave } onMouseUp={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseUp } onMouseDown={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseDown } onKeyDown={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonKeyDown } onChange={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoonChange } ondelay={ props.HolaminombreesErickyyosertuasesorduranteesterecorridoondelay } >{props.HolaminombreesErickyyosertuasesorduranteesterecorrido0 || `Que tipo de seguro es el que estas buscando?`}</span>

            </CSSTransition>
          </div>

        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Rectanglefour.propTypes = {
    style: PropTypes.any,
Rectanglefour0: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorrido0: PropTypes.any,
RectanglefouronClick: PropTypes.any,
RectanglefouronMouseEnter: PropTypes.any,
RectanglefouronMouseOver: PropTypes.any,
RectanglefouronKeyPress: PropTypes.any,
RectanglefouronDrag: PropTypes.any,
RectanglefouronMouseLeave: PropTypes.any,
RectanglefouronMouseUp: PropTypes.any,
RectanglefouronMouseDown: PropTypes.any,
RectanglefouronKeyDown: PropTypes.any,
RectanglefouronChange: PropTypes.any,
Rectanglefourondelay: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonClick: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseEnter: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseOver: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonKeyPress: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonDrag: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseLeave: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseUp: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseDown: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonKeyDown: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoonChange: PropTypes.any,
HolaminombreesErickyyosertuasesorduranteesterecorridoondelay: PropTypes.any
}
export default Rectanglefour;