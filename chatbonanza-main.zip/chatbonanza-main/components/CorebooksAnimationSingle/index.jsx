import React from 'react';
import '../CorebooksAnimation/CorebooksAnimation.css';
import styled from "styled-components";

const AnimationContainerSingleDissolve = styled.div`
  & > * {
    
    transition-property: opacity;
    transition-duration: ${(props) =>props.duration ? props.duration : "500ms"};
    transition-timing-function: ${(props) =>props.easing ? props.easing : "ease"};
  }
`;

const AnimationContainerSingleSmartAnimation = styled.div`
  & > * {
    
    transition-duration: ${(props) =>
      props.duration ? props.duration : "500ms"};
    transition-timing-function: ${(props) =>
      props.easing ? props.easing : "ease"};
    transition-property: all;
  }
`;
const AnimationWithOut = (props)=><>{props.children}</>;

const getTransitionStyles = (transition, active, fromProps)=>{
    /** 
     * width: ${({width}:IFromProps)=>`${width}px`};
    height: ${({height}:IFromProps)=>`${height}px`};
    transform: ${({transform}:IFromProps)=>transform}; 
    background: ${({background}:IFromProps)=>background};  
    */
    switch (transition?.type) {
        case "DISSOLVE":
            return active ? { opacity: 1 } : { opacity: 0 }
        case "SMART_ANIMATE":
            return active ? { } : { ...fromProps }
       
    }
}
const CorebooksAnimationSingle = (props)=>{
    const { fromProps, transition, children} = props;
    const [active, setActive] = React.useState(false);
    let Component = AnimationWithOut;
    switch (transition?.type) {
        case "DISSOLVE":
            Component = AnimationContainerSingleDissolve;
            break;
        case "SMART_ANIMATE":
            Component = AnimationContainerSingleSmartAnimation;
            break;
        default:
            Component = AnimationWithOut;
            break;
    }
    React.useEffect(()=>{

        setActive(false);
        setTimeout(()=>setActive(true), 40)
       
    },[children])
    const clones = React.Children.map(children, child => {
        return React.cloneElement(child, { style: getTransitionStyles(transition, active, fromProps) });
    });
    return( 
    <Component
        className={`animation-container `}
        duration={transition?.duration ? `${transition.duration * 1000}ms` : `ms`}
        easing={transition?.easing?.type ? transition?.easing?.type.toLowerCase().replace(/_/g,'-'): 'ease'}
        { ...fromProps }
    >
    {clones}
  </Component>)
        

}

export default CorebooksAnimationSingle