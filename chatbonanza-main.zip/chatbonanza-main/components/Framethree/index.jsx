import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import Button from 'Components/Button'
import Rectanglefive from 'Components/Rectanglefive'
import './Framethree.css'





const Framethree = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        

        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition nodeRef={nodeRef} in={true} appear={true} timeout={400} classNames={SingletoneNavigation.getTransitionInstance()?.Framethree?.cssClass || '' }>

    <div id="id_one_twoozero" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } framethree ${ props.cssClass } ${ transaction['framethree']?.type ? transaction['framethree']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: `${((SingletoneNavigation.getTransitionInstance()?.Framethree?.duration || 0) * 1000).toFixed(0)}ms` }, ...props.style }} onClick={ props.FramethreeonClick } onMouseEnter={ props.FramethreeonMouseEnter } onMouseOver={ props.FramethreeonMouseOver } onKeyPress={ props.FramethreeonKeyPress } onDrag={ props.FramethreeonDrag } onMouseLeave={ props.FramethreeonMouseLeave } onMouseUp={ props.FramethreeonMouseUp } onMouseDown={ props.FramethreeonMouseDown } onKeyDown={ props.FramethreeonKeyDown } onChange={ props.FramethreeonChange } ondelay={ props.Framethreeondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frameseven']?.animationClass || {}}>

          <div id="id_onezero_onethreezero" className={` frame frameseven ${ props.onClick ? 'cursor' : '' } ${ transaction['frameseven']?.type ? transaction['frameseven']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramesevenStyle , transitionDuration: transaction['frameseven']?.duration, transitionTimingFunction: transaction['frameseven']?.timingFunction } } onClick={ props.FramesevenonClick } onMouseEnter={ props.FramesevenonMouseEnter } onMouseOver={ props.FramesevenonMouseOver } onKeyPress={ props.FramesevenonKeyPress } onDrag={ props.FramesevenonDrag } onMouseLeave={ props.FramesevenonMouseLeave } onMouseUp={ props.FramesevenonMouseUp } onMouseDown={ props.FramesevenonMouseDown } onKeyDown={ props.FramesevenonKeyDown } onChange={ props.FramesevenonChange } ondelay={ props.Framesevenondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['framefive']?.animationClass || {}}>

              <div id="id_onezero_onethreethree" className={` frame framefive ${ props.onClick ? 'cursor' : '' } ${ transaction['framefive']?.type ? transaction['framefive']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramefiveStyle , transitionDuration: transaction['framefive']?.duration, transitionTimingFunction: transaction['framefive']?.timingFunction } } onClick={ props.FramefiveonClick } onMouseEnter={ props.FramefiveonMouseEnter } onMouseOver={ props.FramefiveonMouseOver } onKeyPress={ props.FramefiveonKeyPress } onDrag={ props.FramefiveonDrag } onMouseLeave={ props.FramefiveonMouseLeave } onMouseUp={ props.FramefiveonMouseUp } onMouseDown={ props.FramefiveonMouseDown } onKeyDown={ props.FramefiveonKeyDown } onChange={ props.FramefiveonChange } ondelay={ props.Framefiveondelay }>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imageone']?.animationClass || {}}>
                  <img id="id_onezero_onethreefour" className={` rectangle imageone ${ props.onClick ? 'cursor' : '' } ${ transaction['imageone']?.type ? transaction['imageone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImageoneStyle , transitionDuration: transaction['imageone']?.duration, transitionTimingFunction: transaction['imageone']?.timingFunction }} onClick={ props.ImageoneonClick } onMouseEnter={ props.ImageoneonMouseEnter } onMouseOver={ props.ImageoneonMouseOver } onKeyPress={ props.ImageoneonKeyPress } onDrag={ props.ImageoneonDrag } onMouseLeave={ props.ImageoneonMouseLeave } onMouseUp={ props.ImageoneonMouseUp } onMouseDown={ props.ImageoneonMouseDown } onKeyDown={ props.ImageoneonKeyDown } onChange={ props.ImageoneonChange } ondelay={ props.Imageoneondelay } src={props.Imageone0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/2b3879adf412db478c331faeee5f712f385b76d1.png" } />
                </CSSTransition>
              </div>

            </CSSTransition>
          </div>

        </CSSTransition>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['framefour']?.animationClass || {}}>

          <div id="id_one_twoofour" className={` frame framefour ${ props.onClick ? 'cursor' : '' } ${ transaction['framefour']?.type ? transaction['framefour']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramefourStyle , transitionDuration: transaction['framefour']?.duration, transitionTimingFunction: transaction['framefour']?.timingFunction } } onClick={ props.FramefouronClick } onMouseEnter={ props.FramefouronMouseEnter } onMouseOver={ props.FramefouronMouseOver } onKeyPress={ props.FramefouronKeyPress } onDrag={ props.FramefouronDrag } onMouseLeave={ props.FramefouronMouseLeave } onMouseUp={ props.FramefouronMouseUp } onMouseDown={ props.FramefouronMouseDown } onKeyDown={ props.FramefouronKeyDown } onChange={ props.FramefouronChange } ondelay={ props.Framefourondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frametwoofour']?.animationClass || {}}>

              <div id="id_sixtwoo_twoozerofour" className={` frame frametwoofour ${ props.onClick ? 'cursor' : '' } ${ transaction['frametwoofour']?.type ? transaction['frametwoofour']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrametwoofourStyle , transitionDuration: transaction['frametwoofour']?.duration, transitionTimingFunction: transaction['frametwoofour']?.timingFunction } } onClick={ props.FrametwoofouronClick } onMouseEnter={ props.FrametwoofouronMouseEnter } onMouseOver={ props.FrametwoofouronMouseOver } onKeyPress={ props.FrametwoofouronKeyPress } onDrag={ props.FrametwoofouronDrag } onMouseLeave={ props.FrametwoofouronMouseLeave } onMouseUp={ props.FrametwoofouronMouseUp } onMouseDown={ props.FrametwoofouronMouseDown } onKeyDown={ props.FrametwoofouronKeyDown } onChange={ props.FrametwoofouronChange } ondelay={ props.Frametwoofourondelay }>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglefive']?.animationClass || {}}>
                  <Rectanglefive { ...{ ...props, style:false } } cssClass={"C_sixtwoo_twoozeroseven "}  />
    </CSSTransition >
                    </div>
               
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['framesix']?.animationClass || {}}
    >
    
                    <div id="id_onezero_oneoneone" className={` frame framesix ${ props.onClick ? 'cursor' : '' } ${ transaction['framesix']?.type ? transaction['framesix']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramesixStyle , transitionDuration: transaction['framesix']?.duration, transitionTimingFunction: transaction['framesix']?.timingFunction } } onClick={ props.FramesixonClick } onMouseEnter={ props.FramesixonMouseEnter } onMouseOver={ props.FramesixonMouseOver } onKeyPress={ props.FramesixonKeyPress } onDrag={ props.FramesixonDrag } onMouseLeave={ props.FramesixonMouseLeave } onMouseUp={ props.FramesixonMouseUp } onMouseDown={ props.FramesixonMouseDown } onKeyDown={ props.FramesixonKeyDown } onChange={ props.FramesixonChange } ondelay={ props.Framesixondelay }>
                    <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['button']?.animationClass || {}}>
                      <Button { ...{ ...props, style:false } } cssClass={"C_one_nigththree "}  />
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['button']?.animationClass || {}}
    >
    <Button { ...{ ...props, style:false } }    cssClass={" C_onezero_onetwootwoo "}  />
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['button']?.animationClass || {}}
    >
    <Button { ...{ ...props, style:false } }    cssClass={" C_foureight_fourzerozero "}  />
    </CSSTransition >
                    </div>
               
    </CSSTransition >
                    </div>
               
    </CSSTransition >
            
            </>
        }
        </div>
    
</CSSTransition>
            </>
        
    ) 
}

Framethree.propTypes = {
    style: PropTypes.any,
Imageone0: PropTypes.any,
FramethreeonClick: PropTypes.any,
FramethreeonMouseEnter: PropTypes.any,
FramethreeonMouseOver: PropTypes.any,
FramethreeonKeyPress: PropTypes.any,
FramethreeonDrag: PropTypes.any,
FramethreeonMouseLeave: PropTypes.any,
FramethreeonMouseUp: PropTypes.any,
FramethreeonMouseDown: PropTypes.any,
FramethreeonKeyDown: PropTypes.any,
FramethreeonChange: PropTypes.any,
Framethreeondelay: PropTypes.any,
FramesevenonClick: PropTypes.any,
FramesevenonMouseEnter: PropTypes.any,
FramesevenonMouseOver: PropTypes.any,
FramesevenonKeyPress: PropTypes.any,
FramesevenonDrag: PropTypes.any,
FramesevenonMouseLeave: PropTypes.any,
FramesevenonMouseUp: PropTypes.any,
FramesevenonMouseDown: PropTypes.any,
FramesevenonKeyDown: PropTypes.any,
FramesevenonChange: PropTypes.any,
Framesevenondelay: PropTypes.any,
FramefiveonClick: PropTypes.any,
FramefiveonMouseEnter: PropTypes.any,
FramefiveonMouseOver: PropTypes.any,
FramefiveonKeyPress: PropTypes.any,
FramefiveonDrag: PropTypes.any,
FramefiveonMouseLeave: PropTypes.any,
FramefiveonMouseUp: PropTypes.any,
FramefiveonMouseDown: PropTypes.any,
FramefiveonKeyDown: PropTypes.any,
FramefiveonChange: PropTypes.any,
Framefiveondelay: PropTypes.any,
ImageoneonClick: PropTypes.any,
ImageoneonMouseEnter: PropTypes.any,
ImageoneonMouseOver: PropTypes.any,
ImageoneonKeyPress: PropTypes.any,
ImageoneonDrag: PropTypes.any,
ImageoneonMouseLeave: PropTypes.any,
ImageoneonMouseUp: PropTypes.any,
ImageoneonMouseDown: PropTypes.any,
ImageoneonKeyDown: PropTypes.any,
ImageoneonChange: PropTypes.any,
Imageoneondelay: PropTypes.any,
FramefouronClick: PropTypes.any,
FramefouronMouseEnter: PropTypes.any,
FramefouronMouseOver: PropTypes.any,
FramefouronKeyPress: PropTypes.any,
FramefouronDrag: PropTypes.any,
FramefouronMouseLeave: PropTypes.any,
FramefouronMouseUp: PropTypes.any,
FramefouronMouseDown: PropTypes.any,
FramefouronKeyDown: PropTypes.any,
FramefouronChange: PropTypes.any,
Framefourondelay: PropTypes.any,
FrametwoofouronClick: PropTypes.any,
FrametwoofouronMouseEnter: PropTypes.any,
FrametwoofouronMouseOver: PropTypes.any,
FrametwoofouronKeyPress: PropTypes.any,
FrametwoofouronDrag: PropTypes.any,
FrametwoofouronMouseLeave: PropTypes.any,
FrametwoofouronMouseUp: PropTypes.any,
FrametwoofouronMouseDown: PropTypes.any,
FrametwoofouronKeyDown: PropTypes.any,
FrametwoofouronChange: PropTypes.any,
Frametwoofourondelay: PropTypes.any,
FramesixonClick: PropTypes.any,
FramesixonMouseEnter: PropTypes.any,
FramesixonMouseOver: PropTypes.any,
FramesixonKeyPress: PropTypes.any,
FramesixonDrag: PropTypes.any,
FramesixonMouseLeave: PropTypes.any,
FramesixonMouseUp: PropTypes.any,
FramesixonMouseDown: PropTypes.any,
FramesixonKeyDown: PropTypes.any,
FramesixonChange: PropTypes.any,
Framesixondelay: PropTypes.any
}
export default Framethree;