import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import Groupone from 'Components/Groupone'
import './Menuoneeighttwootwoo.css'





const Menuoneeighttwootwoo = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['menuoneeighttwootwoo']?.animationClass || {}}>

    <div id="id_sixthree_twoosevenone" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } menuoneeighttwootwoo ${ props.cssClass } ${ transaction['menuoneeighttwootwoo']?.type ? transaction['menuoneeighttwootwoo']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['menuoneeighttwootwoo']?.duration, transitionTimingFunction: transaction['menuoneeighttwootwoo']?.timingFunction }, ...props.style }} onClick={ props.MenuoneeighttwootwooonClick } onMouseEnter={ props.MenuoneeighttwootwooonMouseEnter } onMouseOver={ props.MenuoneeighttwootwooonMouseOver } onKeyPress={ props.MenuoneeighttwootwooonKeyPress } onDrag={ props.MenuoneeighttwootwooonDrag } onMouseLeave={ props.MenuoneeighttwootwooonMouseLeave } onMouseUp={ props.MenuoneeighttwootwooonMouseUp } onMouseDown={ props.MenuoneeighttwootwooonMouseDown } onKeyDown={ props.MenuoneeighttwootwooonKeyDown } onChange={ props.MenuoneeighttwootwooonChange } ondelay={ props.Menuoneeighttwootwooondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frametwootwoo']?.animationClass || {}}>

          <div id="id_sixthree_twooseventwoo" className={` frame frametwootwoo ${ props.onClick ? 'cursor' : '' } ${ transaction['frametwootwoo']?.type ? transaction['frametwootwoo']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrametwootwooStyle , transitionDuration: transaction['frametwootwoo']?.duration, transitionTimingFunction: transaction['frametwootwoo']?.timingFunction } } onClick={ props.FrametwootwooonClick } onMouseEnter={ props.FrametwootwooonMouseEnter } onMouseOver={ props.FrametwootwooonMouseOver } onKeyPress={ props.FrametwootwooonKeyPress } onDrag={ props.FrametwootwooonDrag } onMouseLeave={ props.FrametwootwooonMouseLeave } onMouseUp={ props.FrametwootwooonMouseUp } onMouseDown={ props.FrametwootwooonMouseDown } onKeyDown={ props.FrametwootwooonKeyDown } onChange={ props.FrametwootwooonChange } ondelay={ props.Frametwootwooondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.animationClass || {}}>
              <img id="id_sixthree_twooseventhree" className={` rectangle imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.timingFunction }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneondelay } src={props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/7e93ca74d6b11bd6b56f65ba04caacf727dd20fb.png" } />
            </CSSTransition>
          </div>

        </CSSTransition>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['groupone']?.animationClass || {}}>
          <Groupone { ...{ ...props, style:false } } cssClass={"C_sixthree_twooeightfour "}  />
    </CSSTransition >
            
            </>
        }
        </div>
    
    </CSSTransition >
            </>
        
    ) 
}

Menuoneeighttwootwoo.propTypes = {
    style: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone0: PropTypes.any,
MenuoneeighttwootwooonClick: PropTypes.any,
MenuoneeighttwootwooonMouseEnter: PropTypes.any,
MenuoneeighttwootwooonMouseOver: PropTypes.any,
MenuoneeighttwootwooonKeyPress: PropTypes.any,
MenuoneeighttwootwooonDrag: PropTypes.any,
MenuoneeighttwootwooonMouseLeave: PropTypes.any,
MenuoneeighttwootwooonMouseUp: PropTypes.any,
MenuoneeighttwootwooonMouseDown: PropTypes.any,
MenuoneeighttwootwooonKeyDown: PropTypes.any,
MenuoneeighttwootwooonChange: PropTypes.any,
Menuoneeighttwootwooondelay: PropTypes.any,
FrametwootwooonClick: PropTypes.any,
FrametwootwooonMouseEnter: PropTypes.any,
FrametwootwooonMouseOver: PropTypes.any,
FrametwootwooonKeyPress: PropTypes.any,
FrametwootwooonDrag: PropTypes.any,
FrametwootwooonMouseLeave: PropTypes.any,
FrametwootwooonMouseUp: PropTypes.any,
FrametwootwooonMouseDown: PropTypes.any,
FrametwootwooonKeyDown: PropTypes.any,
FrametwootwooonChange: PropTypes.any,
Frametwootwooondelay: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonClick: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseEnter: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseOver: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyPress: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonDrag: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseLeave: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseUp: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonChange: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneondelay: PropTypes.any
}
export default Menuoneeighttwootwoo;