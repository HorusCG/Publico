import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Button.css'





const Button = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['button']?.animationClass || {}}>

    <div id="id_foureight_fourzerozero" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } button C_foureight_fourzerozero ${ props.cssClass } ${ transaction['button']?.type ? transaction['button']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['button']?.duration, transitionTimingFunction: transaction['button']?.timingFunction }, ...props.style }} onClick={ props.ButtononClick } onMouseEnter={ props.ButtononMouseEnter } onMouseOver={ props.ButtononMouseOver } onKeyPress={ props.ButtononKeyPress } onDrag={ props.ButtononDrag } onMouseLeave={ props.ButtononMouseLeave } onMouseUp={ props.ButtononMouseUp } onMouseDown={ props.ButtononMouseDown } onKeyDown={ props.ButtononKeyDown } onChange={ props.ButtononChange } ondelay={ props.Buttonondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['button']?.animationClass || {}}>

          <div id="id_onezerozero_sixzerozero" className={` frame button ${ props.onClick ? 'cursor' : '' } ${ transaction['button']?.type ? transaction['button']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.ButtonStyle , transitionDuration: transaction['button']?.duration, transitionTimingFunction: transaction['button']?.timingFunction } } onClick={ props.ButtononClick } onMouseEnter={ props.ButtononMouseEnter } onMouseOver={ props.ButtononMouseOver } onKeyPress={ props.ButtononKeyPress } onDrag={ props.ButtononDrag } onMouseLeave={ props.ButtononMouseLeave } onMouseUp={ props.ButtononMouseUp } onMouseDown={ props.ButtononMouseDown } onKeyDown={ props.ButtononKeyDown } onChange={ props.ButtononChange } ondelay={ props.Buttonondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['oneeighttwootwoo']?.animationClass || {}}>

              <span id="id_onezerozero_sixzeroone"  className={` text oneeighttwootwoo    ${ props.onClick ? 'cursor' : ''}  ${ transaction['oneeighttwootwoo']?.type ? transaction['oneeighttwootwoo']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.oneeighttwootwooStyle , transitionDuration: transaction['oneeighttwootwoo']?.duration, transitionTimingFunction: transaction['oneeighttwootwoo']?.timingFunction }} onClick={ props.OneeighttwootwooonClick } onMouseEnter={ props.OneeighttwootwooonMouseEnter } onMouseOver={ props.OneeighttwootwooonMouseOver } onKeyPress={ props.OneeighttwootwooonKeyPress } onDrag={ props.OneeighttwootwooonDrag } onMouseLeave={ props.OneeighttwootwooonMouseLeave } onMouseUp={ props.OneeighttwootwooonMouseUp } onMouseDown={ props.OneeighttwootwooonMouseDown } onKeyDown={ props.OneeighttwootwooonKeyDown } onChange={ props.OneeighttwootwooonChange } ondelay={ props.Oneeighttwootwooondelay } >{props.Oneeighttwootwoo0 || `31-38`}</span>

            </CSSTransition>
          </div>

        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Button.propTypes = {
    style: PropTypes.any,
Oneeighttwootwoo0: PropTypes.any,
ButtononClick: PropTypes.any,
ButtononMouseEnter: PropTypes.any,
ButtononMouseOver: PropTypes.any,
ButtononKeyPress: PropTypes.any,
ButtononDrag: PropTypes.any,
ButtononMouseLeave: PropTypes.any,
ButtononMouseUp: PropTypes.any,
ButtononMouseDown: PropTypes.any,
ButtononKeyDown: PropTypes.any,
ButtononChange: PropTypes.any,
Buttonondelay: PropTypes.any,
OneeighttwootwooonClick: PropTypes.any,
OneeighttwootwooonMouseEnter: PropTypes.any,
OneeighttwootwooonMouseOver: PropTypes.any,
OneeighttwootwooonKeyPress: PropTypes.any,
OneeighttwootwooonDrag: PropTypes.any,
OneeighttwootwooonMouseLeave: PropTypes.any,
OneeighttwootwooonMouseUp: PropTypes.any,
OneeighttwootwooonMouseDown: PropTypes.any,
OneeighttwootwooonKeyDown: PropTypes.any,
OneeighttwootwooonChange: PropTypes.any,
Oneeighttwootwooondelay: PropTypes.any
}
export default Button;