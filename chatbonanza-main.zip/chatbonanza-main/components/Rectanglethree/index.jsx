import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Rectanglethree.css'





const Rectanglethree = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglethree']?.animationClass || {}}>

    <div id="id_onezerozero_nigthfourone" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } rectanglethree C_onezerozero_nigthfourone ${ props.cssClass } ${ transaction['rectanglethree']?.type ? transaction['rectanglethree']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['rectanglethree']?.duration, transitionTimingFunction: transaction['rectanglethree']?.timingFunction }, ...props.style }} onClick={ props.RectanglethreeonClick } onMouseEnter={ props.RectanglethreeonMouseEnter } onMouseOver={ props.RectanglethreeonMouseOver } onKeyPress={ props.RectanglethreeonKeyPress } onDrag={ props.RectanglethreeonDrag } onMouseLeave={ props.RectanglethreeonMouseLeave } onMouseUp={ props.RectanglethreeonMouseUp } onMouseDown={ props.RectanglethreeonMouseDown } onKeyDown={ props.RectanglethreeonKeyDown } onChange={ props.RectanglethreeonChange } ondelay={ props.Rectanglethreeondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglethree']?.animationClass || {}}>

          <div id="id_onezerozero_nigthfourtwoo" className={` frame rectanglethree ${ props.onClick ? 'cursor' : '' } ${ transaction['rectanglethree']?.type ? transaction['rectanglethree']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.RectanglethreeStyle , transitionDuration: transaction['rectanglethree']?.duration, transitionTimingFunction: transaction['rectanglethree']?.timingFunction } } onClick={ props.RectanglethreeonClick } onMouseEnter={ props.RectanglethreeonMouseEnter } onMouseOver={ props.RectanglethreeonMouseOver } onKeyPress={ props.RectanglethreeonKeyPress } onDrag={ props.RectanglethreeonDrag } onMouseLeave={ props.RectanglethreeonMouseLeave } onMouseUp={ props.RectanglethreeonMouseUp } onMouseDown={ props.RectanglethreeonMouseDown } onKeyDown={ props.RectanglethreeonKeyDown } onChange={ props.RectanglethreeonChange } ondelay={ props.Rectanglethreeondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectanglethree']?.animationClass || {}}>
              <div id="id_onezerozero_nigthfourthree" className={` rectangle rectanglethree ${ props.onClick ? 'cursor' : '' } ${ transaction['rectanglethree']?.type ? transaction['rectanglethree']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.RectanglethreeStyle , transitionDuration: transaction['rectanglethree']?.duration, transitionTimingFunction: transaction['rectanglethree']?.timingFunction }} onClick={ props.RectanglethreeonClick } onMouseEnter={ props.RectanglethreeonMouseEnter } onMouseOver={ props.RectanglethreeonMouseOver } onKeyPress={ props.RectanglethreeonKeyPress } onDrag={ props.RectanglethreeonDrag } onMouseLeave={ props.RectanglethreeonMouseLeave } onMouseUp={ props.RectanglethreeonMouseUp } onMouseDown={ props.RectanglethreeonMouseDown } onKeyDown={ props.RectanglethreeonKeyDown } onChange={ props.RectanglethreeonChange } ondelay={ props.Rectanglethreeondelay }></div>
            </CSSTransition>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['tepuedobrindarconocimientosqutemategustariaconocer']?.animationClass || {}}>

              <span id="id_onezerozero_nigthfourfour"  className={` text tepuedobrindarconocimientosqutemategustariaconocer    ${ props.onClick ? 'cursor' : ''}  ${ transaction['tepuedobrindarconocimientosqutemategustariaconocer']?.type ? transaction['tepuedobrindarconocimientosqutemategustariaconocer']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.TepuedobrindarconocimientosQutemategustariaconocerStyle , transitionDuration: transaction['tepuedobrindarconocimientosqutemategustariaconocer']?.duration, transitionTimingFunction: transaction['tepuedobrindarconocimientosqutemategustariaconocer']?.timingFunction }} onClick={ props.TepuedobrindarconocimientosQutemategustariaconoceronClick } onMouseEnter={ props.TepuedobrindarconocimientosQutemategustariaconoceronMouseEnter } onMouseOver={ props.TepuedobrindarconocimientosQutemategustariaconoceronMouseOver } onKeyPress={ props.TepuedobrindarconocimientosQutemategustariaconoceronKeyPress } onDrag={ props.TepuedobrindarconocimientosQutemategustariaconoceronDrag } onMouseLeave={ props.TepuedobrindarconocimientosQutemategustariaconoceronMouseLeave } onMouseUp={ props.TepuedobrindarconocimientosQutemategustariaconoceronMouseUp } onMouseDown={ props.TepuedobrindarconocimientosQutemategustariaconoceronMouseDown } onKeyDown={ props.TepuedobrindarconocimientosQutemategustariaconoceronKeyDown } onChange={ props.TepuedobrindarconocimientosQutemategustariaconoceronChange } ondelay={ props.TepuedobrindarconocimientosQutemategustariaconocerondelay } >{props.TepuedobrindarconocimientosQutemategustariaconocer0 || `Te puedo ayudar a adquirir conocimientos. ¿Qué tema quieres aprender?`}</span>

            </CSSTransition>
          </div>

        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Rectanglethree.propTypes = {
    style: PropTypes.any,
Rectanglethree0: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconocer0: PropTypes.any,
RectanglethreeonClick: PropTypes.any,
RectanglethreeonMouseEnter: PropTypes.any,
RectanglethreeonMouseOver: PropTypes.any,
RectanglethreeonKeyPress: PropTypes.any,
RectanglethreeonDrag: PropTypes.any,
RectanglethreeonMouseLeave: PropTypes.any,
RectanglethreeonMouseUp: PropTypes.any,
RectanglethreeonMouseDown: PropTypes.any,
RectanglethreeonKeyDown: PropTypes.any,
RectanglethreeonChange: PropTypes.any,
Rectanglethreeondelay: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronClick: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronMouseEnter: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronMouseOver: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronKeyPress: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronDrag: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronMouseLeave: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronMouseUp: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronMouseDown: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronKeyDown: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconoceronChange: PropTypes.any,
TepuedobrindarconocimientosQutemategustariaconocerondelay: PropTypes.any
}
export default Rectanglethree;