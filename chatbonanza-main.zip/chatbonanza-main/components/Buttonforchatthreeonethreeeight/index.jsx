import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Buttonforchatthreeonethreeeight.css'





const Buttonforchatthreeonethreeeight = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['buttonforchatthreeonethreeeight']?.animationClass || {}}>

    <div id="id_onethree_fiveone" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } buttonforchatthreeonethreeeight ${ props.cssClass } ${ transaction['buttonforchatthreeonethreeeight']?.type ? transaction['buttonforchatthreeonethreeeight']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['buttonforchatthreeonethreeeight']?.duration, transitionTimingFunction: transaction['buttonforchatthreeonethreeeight']?.timingFunction }, ...props.style }} onClick={ props.ButtonforchatthreeonethreeeightonClick } onMouseEnter={ props.ButtonforchatthreeonethreeeightonMouseEnter } onMouseOver={ props.ButtonforchatthreeonethreeeightonMouseOver } onKeyPress={ props.ButtonforchatthreeonethreeeightonKeyPress } onDrag={ props.ButtonforchatthreeonethreeeightonDrag } onMouseLeave={ props.ButtonforchatthreeonethreeeightonMouseLeave } onMouseUp={ props.ButtonforchatthreeonethreeeightonMouseUp } onMouseDown={ props.ButtonforchatthreeonethreeeightonMouseDown } onKeyDown={ props.ButtonforchatthreeonethreeeightonKeyDown } onChange={ props.ButtonforchatthreeonethreeeightonChange } ondelay={ props.Buttonforchatthreeonethreeeightondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofiveone']?.animationClass || {}}>
          <img id="id_onethree_fivezero" className={` rectangle imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofiveone ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofiveone']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofiveone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofiveone']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasonenigthzerofiveone']?.timingFunction }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneondelay } src={props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveone0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/14e49ff30b9feb8e248b346f5c98144e629be70f.png" } />
        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Buttonforchatthreeonethreeeight.propTypes = {
    style: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveone0: PropTypes.any,
ButtonforchatthreeonethreeeightonClick: PropTypes.any,
ButtonforchatthreeonethreeeightonMouseEnter: PropTypes.any,
ButtonforchatthreeonethreeeightonMouseOver: PropTypes.any,
ButtonforchatthreeonethreeeightonKeyPress: PropTypes.any,
ButtonforchatthreeonethreeeightonDrag: PropTypes.any,
ButtonforchatthreeonethreeeightonMouseLeave: PropTypes.any,
ButtonforchatthreeonethreeeightonMouseUp: PropTypes.any,
ButtonforchatthreeonethreeeightonMouseDown: PropTypes.any,
ButtonforchatthreeonethreeeightonKeyDown: PropTypes.any,
ButtonforchatthreeonethreeeightonChange: PropTypes.any,
Buttonforchatthreeonethreeeightondelay: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonClick: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseEnter: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseOver: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonKeyPress: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonDrag: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseLeave: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseUp: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonMouseDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonKeyDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneonChange: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasonenigthzerofiveoneondelay: PropTypes.any
}
export default Buttonforchatthreeonethreeeight;