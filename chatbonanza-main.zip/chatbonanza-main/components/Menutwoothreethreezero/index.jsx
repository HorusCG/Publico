import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import Frametwoofive from 'Components/Frametwoofive'
import './Menutwoothreethreezero.css'





const Menutwoothreethreezero = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['menutwoothreethreezero']?.animationClass || {}}>

    <div id="id_sixthree_twoosixtwoo" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } menutwoothreethreezero ${ props.cssClass } ${ transaction['menutwoothreethreezero']?.type ? transaction['menutwoothreethreezero']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['menutwoothreethreezero']?.duration, transitionTimingFunction: transaction['menutwoothreethreezero']?.timingFunction }, ...props.style }} onClick={ props.MenutwoothreethreezeroonClick } onMouseEnter={ props.MenutwoothreethreezeroonMouseEnter } onMouseOver={ props.MenutwoothreethreezeroonMouseOver } onKeyPress={ props.MenutwoothreethreezeroonKeyPress } onDrag={ props.MenutwoothreethreezeroonDrag } onMouseLeave={ props.MenutwoothreethreezeroonMouseLeave } onMouseUp={ props.MenutwoothreethreezeroonMouseUp } onMouseDown={ props.MenutwoothreethreezeroonMouseDown } onKeyDown={ props.MenutwoothreethreezeroonKeyDown } onChange={ props.MenutwoothreethreezeroonChange } ondelay={ props.Menutwoothreethreezeroondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frametwootwoo']?.animationClass || {}}>

          <div id="id_sixthree_twoosixthree" className={` frame frametwootwoo ${ props.onClick ? 'cursor' : '' } ${ transaction['frametwootwoo']?.type ? transaction['frametwootwoo']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrametwootwooStyle , transitionDuration: transaction['frametwootwoo']?.duration, transitionTimingFunction: transaction['frametwootwoo']?.timingFunction } } onClick={ props.FrametwootwooonClick } onMouseEnter={ props.FrametwootwooonMouseEnter } onMouseOver={ props.FrametwootwooonMouseOver } onKeyPress={ props.FrametwootwooonKeyPress } onDrag={ props.FrametwootwooonDrag } onMouseLeave={ props.FrametwootwooonMouseLeave } onMouseUp={ props.FrametwootwooonMouseUp } onMouseDown={ props.FrametwootwooonMouseDown } onKeyDown={ props.FrametwootwooonKeyDown } onChange={ props.FrametwootwooonChange } ondelay={ props.Frametwootwooondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.animationClass || {}}>
              <img id="id_sixthree_twoosixfour" className={` rectangle imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone']?.timingFunction }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneondelay } src={props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/7e93ca74d6b11bd6b56f65ba04caacf727dd20fb.png" } />
            </CSSTransition>
          </div>

        </CSSTransition>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['groupone']?.animationClass || {}}>

          <div id="id_sixthree_twoosixfive" className={` group groupone ${ props.onClick ? 'cursor' : '' } ${ transaction['groupone']?.type ? transaction['groupone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.GrouponeStyle , transitionDuration: transaction['groupone']?.duration, transitionTimingFunction: transaction['groupone']?.timingFunction }} onClick={ props.GrouponeonClick } onMouseEnter={ props.GrouponeonMouseEnter } onMouseOver={ props.GrouponeonMouseOver } onKeyPress={ props.GrouponeonKeyPress } onDrag={ props.GrouponeonDrag } onMouseLeave={ props.GrouponeonMouseLeave } onMouseUp={ props.GrouponeonMouseUp } onMouseDown={ props.GrouponeonMouseDown } onKeyDown={ props.GrouponeonKeyDown } onChange={ props.GrouponeonChange } ondelay={ props.Grouponeondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frametwoofive']?.animationClass || {}}>
              <Frametwoofive { ...{ ...props, style:false } } cssClass={"C_sixthree_twooeightfive "}  />
    </CSSTransition >
                </div>
            
    </CSSTransition >
            
            </>
        }
        </div>
    
    </CSSTransition >
            </>
        
    ) 
}

Menutwoothreethreezero.propTypes = {
    style: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone0: PropTypes.any,
MenutwoothreethreezeroonClick: PropTypes.any,
MenutwoothreethreezeroonMouseEnter: PropTypes.any,
MenutwoothreethreezeroonMouseOver: PropTypes.any,
MenutwoothreethreezeroonKeyPress: PropTypes.any,
MenutwoothreethreezeroonDrag: PropTypes.any,
MenutwoothreethreezeroonMouseLeave: PropTypes.any,
MenutwoothreethreezeroonMouseUp: PropTypes.any,
MenutwoothreethreezeroonMouseDown: PropTypes.any,
MenutwoothreethreezeroonKeyDown: PropTypes.any,
MenutwoothreethreezeroonChange: PropTypes.any,
Menutwoothreethreezeroondelay: PropTypes.any,
FrametwootwooonClick: PropTypes.any,
FrametwootwooonMouseEnter: PropTypes.any,
FrametwootwooonMouseOver: PropTypes.any,
FrametwootwooonKeyPress: PropTypes.any,
FrametwootwooonDrag: PropTypes.any,
FrametwootwooonMouseLeave: PropTypes.any,
FrametwootwooonMouseUp: PropTypes.any,
FrametwootwooonMouseDown: PropTypes.any,
FrametwootwooonKeyDown: PropTypes.any,
FrametwootwooonChange: PropTypes.any,
Frametwootwooondelay: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonClick: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseEnter: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseOver: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyPress: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonDrag: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseLeave: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseUp: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonChange: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneondelay: PropTypes.any,
GrouponeonClick: PropTypes.any,
GrouponeonMouseEnter: PropTypes.any,
GrouponeonMouseOver: PropTypes.any,
GrouponeonKeyPress: PropTypes.any,
GrouponeonDrag: PropTypes.any,
GrouponeonMouseLeave: PropTypes.any,
GrouponeonMouseUp: PropTypes.any,
GrouponeonMouseDown: PropTypes.any,
GrouponeonKeyDown: PropTypes.any,
GrouponeonChange: PropTypes.any,
Grouponeondelay: PropTypes.any
}
export default Menutwoothreethreezero;