# README
## Props
 - style
## Loca states

## Events
 - SegurosaludviejitoonClick
 - SegurosaludviejitoonMouseEnter
 - SegurosaludviejitoonMouseOver
 - SegurosaludviejitoonKeyPress
 - SegurosaludviejitoonDrag
 - SegurosaludviejitoonMouseLeave
 - SegurosaludviejitoonMouseUp
 - SegurosaludviejitoonMouseDown
 - SegurosaludviejitoonKeyDown
 - SegurosaludviejitoonChange
 - Segurosaludviejitoondelay
 - FramesixonClick
 - FramesixonMouseEnter
 - FramesixonMouseOver
 - FramesixonKeyPress
 - FramesixonDrag
 - FramesixonMouseLeave
 - FramesixonMouseUp
 - FramesixonMouseDown
 - FramesixonKeyDown
 - FramesixonChange
 - Framesixondelay 