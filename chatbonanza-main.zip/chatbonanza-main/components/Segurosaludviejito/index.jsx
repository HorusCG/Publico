import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import Button from 'Components/Button'
import Framethree from 'Components/Framethree'
import './Segurosaludviejito.css'





const Segurosaludviejito = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['segurosaludviejito']?.animationClass || {}}>

    <div id="id_fourseven_sixzeroone" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } segurosaludviejito ${ props.cssClass } ${ transaction['segurosaludviejito']?.type ? transaction['segurosaludviejito']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['segurosaludviejito']?.duration, transitionTimingFunction: transaction['segurosaludviejito']?.timingFunction }, ...props.style }} onClick={ props.SegurosaludviejitoonClick } onMouseEnter={ props.SegurosaludviejitoonMouseEnter } onMouseOver={ props.SegurosaludviejitoonMouseOver } onKeyPress={ props.SegurosaludviejitoonKeyPress } onDrag={ props.SegurosaludviejitoonDrag } onMouseLeave={ props.SegurosaludviejitoonMouseLeave } onMouseUp={ props.SegurosaludviejitoonMouseUp } onMouseDown={ props.SegurosaludviejitoonMouseDown } onKeyDown={ props.SegurosaludviejitoonKeyDown } onChange={ props.SegurosaludviejitoonChange } ondelay={ props.Segurosaludviejitoondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['framethree']?.animationClass || {}}>
          <Framethree { ...{ ...props, style:false } } cssClass={"C_seventwoo_eightzerozero "}  />
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['framesix']?.animationClass || {}}
    >
    
                    <div id="id_onezerozero_onezerofourthree" className={` frame framesix ${ props.onClick ? 'cursor' : '' } ${ transaction['framesix']?.type ? transaction['framesix']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FramesixStyle , transitionDuration: transaction['framesix']?.duration, transitionTimingFunction: transaction['framesix']?.timingFunction } } onClick={ props.FramesixonClick } onMouseEnter={ props.FramesixonMouseEnter } onMouseOver={ props.FramesixonMouseOver } onKeyPress={ props.FramesixonKeyPress } onDrag={ props.FramesixonDrag } onMouseLeave={ props.FramesixonMouseLeave } onMouseUp={ props.FramesixonMouseUp } onMouseDown={ props.FramesixonMouseDown } onKeyDown={ props.FramesixonKeyDown } onChange={ props.FramesixonChange } ondelay={ props.Framesixondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['button']?.animationClass || {}}>
              <Button { ...{ ...props, style:false } } cssClass={"C_onezerozero_onezerofourseven "}  />
    </CSSTransition >
                    </div>
               
    </CSSTransition >
            
            </>
        }
        </div>
    
    </CSSTransition >
            </>
        
    ) 
}

Segurosaludviejito.propTypes = {
    style: PropTypes.any,
SegurosaludviejitoonClick: PropTypes.any,
SegurosaludviejitoonMouseEnter: PropTypes.any,
SegurosaludviejitoonMouseOver: PropTypes.any,
SegurosaludviejitoonKeyPress: PropTypes.any,
SegurosaludviejitoonDrag: PropTypes.any,
SegurosaludviejitoonMouseLeave: PropTypes.any,
SegurosaludviejitoonMouseUp: PropTypes.any,
SegurosaludviejitoonMouseDown: PropTypes.any,
SegurosaludviejitoonKeyDown: PropTypes.any,
SegurosaludviejitoonChange: PropTypes.any,
Segurosaludviejitoondelay: PropTypes.any,
FramesixonClick: PropTypes.any,
FramesixonMouseEnter: PropTypes.any,
FramesixonMouseOver: PropTypes.any,
FramesixonKeyPress: PropTypes.any,
FramesixonDrag: PropTypes.any,
FramesixonMouseLeave: PropTypes.any,
FramesixonMouseUp: PropTypes.any,
FramesixonMouseDown: PropTypes.any,
FramesixonKeyDown: PropTypes.any,
FramesixonChange: PropTypes.any,
Framesixondelay: PropTypes.any
}
export default Segurosaludviejito;