import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Buttonforchattwoothreethreezero.css'





const Buttonforchattwoothreethreezero = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['buttonforchattwoothreethreezero']?.animationClass || {}}>

    <div id="id_onethree_fourthree" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } buttonforchattwoothreethreezero ${ props.cssClass } ${ transaction['buttonforchattwoothreethreezero']?.type ? transaction['buttonforchattwoothreethreezero']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['buttonforchattwoothreethreezero']?.duration, transitionTimingFunction: transaction['buttonforchattwoothreethreezero']?.timingFunction }, ...props.style }} onClick={ props.ButtonforchattwoothreethreezeroonClick } onMouseEnter={ props.ButtonforchattwoothreethreezeroonMouseEnter } onMouseOver={ props.ButtonforchattwoothreethreezeroonMouseOver } onKeyPress={ props.ButtonforchattwoothreethreezeroonKeyPress } onDrag={ props.ButtonforchattwoothreethreezeroonDrag } onMouseLeave={ props.ButtonforchattwoothreethreezeroonMouseLeave } onMouseUp={ props.ButtonforchattwoothreethreezeroonMouseUp } onMouseDown={ props.ButtonforchattwoothreethreezeroonMouseDown } onKeyDown={ props.ButtonforchattwoothreethreezeroonKeyDown } onChange={ props.ButtonforchattwoothreethreezeroonChange } ondelay={ props.Buttonforchattwoothreethreezeroondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.animationClass || {}}>
          <img id="id_onethree_fourfour" className={` rectangle imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.timingFunction }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneondelay } src={props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/0c288ebf71f2862e0ba7b04dda2e0e29e0921e9f.png" } />
        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Buttonforchattwoothreethreezero.propTypes = {
    style: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone0: PropTypes.any,
ButtonforchattwoothreethreezeroonClick: PropTypes.any,
ButtonforchattwoothreethreezeroonMouseEnter: PropTypes.any,
ButtonforchattwoothreethreezeroonMouseOver: PropTypes.any,
ButtonforchattwoothreethreezeroonKeyPress: PropTypes.any,
ButtonforchattwoothreethreezeroonDrag: PropTypes.any,
ButtonforchattwoothreethreezeroonMouseLeave: PropTypes.any,
ButtonforchattwoothreethreezeroonMouseUp: PropTypes.any,
ButtonforchattwoothreethreezeroonMouseDown: PropTypes.any,
ButtonforchattwoothreethreezeroonKeyDown: PropTypes.any,
ButtonforchattwoothreethreezeroonChange: PropTypes.any,
Buttonforchattwoothreethreezeroondelay: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonClick: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseEnter: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseOver: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyPress: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonDrag: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseLeave: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseUp: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonChange: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneondelay: PropTypes.any
}
export default Buttonforchattwoothreethreezero;