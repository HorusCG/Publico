import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import Rectangleone from 'Components/Rectangleone'
import Framethree from 'Components/Framethree'
import './Registro.css'





const Registro = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        

        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition nodeRef={nodeRef} in={true} appear={true} timeout={400} classNames={SingletoneNavigation.getTransitionInstance()?.Registro?.cssClass || '' }>

    <div id="id_one_onefour" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } registro ${ props.cssClass } ${ transaction['registro']?.type ? transaction['registro']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: `${((SingletoneNavigation.getTransitionInstance()?.Registro?.duration || 0) * 1000).toFixed(0)}ms` }, ...props.style }} onClick={ props.RegistroonClick } onMouseEnter={ props.RegistroonMouseEnter } onMouseOver={ props.RegistroonMouseOver } onKeyPress={ props.RegistroonKeyPress } onDrag={ props.RegistroonDrag } onMouseLeave={ props.RegistroonMouseLeave } onMouseUp={ props.RegistroonMouseUp } onMouseDown={ props.RegistroonMouseDown } onKeyDown={ props.RegistroonKeyDown } onChange={ props.RegistroonChange } ondelay={ props.Registroondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['framethree']?.animationClass || {}}>
          <Framethree { ...{ ...props, style:false } } cssClass={"C_one_twoozero "}  />
    </CSSTransition >
<CSSTransition 
        in={_in}
        appear={true} 
        timeout={100}
        classNames={transaction['cuadrodetexto']?.animationClass || {}}
    >
    
                    <div id="id_one_onefive" className={` frame cuadrodetexto ${ props.onClick ? 'cursor' : '' } ${ transaction['cuadrodetexto']?.type ? transaction['cuadrodetexto']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.CuadrodetextoStyle , transitionDuration: transaction['cuadrodetexto']?.duration, transitionTimingFunction: transaction['cuadrodetexto']?.timingFunction } } onClick={ props.CuadrodetextoonClick } onMouseEnter={ props.CuadrodetextoonMouseEnter } onMouseOver={ props.CuadrodetextoonMouseOver } onKeyPress={ props.CuadrodetextoonKeyPress } onDrag={ props.CuadrodetextoonDrag } onMouseLeave={ props.CuadrodetextoonMouseLeave } onMouseUp={ props.CuadrodetextoonMouseUp } onMouseDown={ props.CuadrodetextoonMouseDown } onKeyDown={ props.CuadrodetextoonKeyDown } onChange={ props.CuadrodetextoonChange } ondelay={ props.Cuadrodetextoondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectangleone']?.animationClass || {}}>
              <Rectangleone { ...{ ...props, style:false } } cssClass={"C_onetwoo_twoozeronigth "}  />
    </CSSTransition >
                    </div>
               
    </CSSTransition >
            
            </>
        }
        </div>
    
</CSSTransition>
            </>
        
    ) 
}

Registro.propTypes = {
    style: PropTypes.any,
RegistroonClick: PropTypes.any,
RegistroonMouseEnter: PropTypes.any,
RegistroonMouseOver: PropTypes.any,
RegistroonKeyPress: PropTypes.any,
RegistroonDrag: PropTypes.any,
RegistroonMouseLeave: PropTypes.any,
RegistroonMouseUp: PropTypes.any,
RegistroonMouseDown: PropTypes.any,
RegistroonKeyDown: PropTypes.any,
RegistroonChange: PropTypes.any,
Registroondelay: PropTypes.any,
CuadrodetextoonClick: PropTypes.any,
CuadrodetextoonMouseEnter: PropTypes.any,
CuadrodetextoonMouseOver: PropTypes.any,
CuadrodetextoonKeyPress: PropTypes.any,
CuadrodetextoonDrag: PropTypes.any,
CuadrodetextoonMouseLeave: PropTypes.any,
CuadrodetextoonMouseUp: PropTypes.any,
CuadrodetextoonMouseDown: PropTypes.any,
CuadrodetextoonKeyDown: PropTypes.any,
CuadrodetextoonChange: PropTypes.any,
Cuadrodetextoondelay: PropTypes.any
}
export default Registro;