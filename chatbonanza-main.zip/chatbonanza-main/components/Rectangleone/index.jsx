import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Rectangleone.css'





const Rectangleone = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectangleone']?.animationClass || {}}>

    <div id="id_onetwoo_twoozeronigth" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } rectangleone C_onetwoo_twoozeronigth ${ props.cssClass } ${ transaction['rectangleone']?.type ? transaction['rectangleone']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['rectangleone']?.duration, transitionTimingFunction: transaction['rectangleone']?.timingFunction }, ...props.style }} onClick={ props.RectangleoneonClick } onMouseEnter={ props.RectangleoneonMouseEnter } onMouseOver={ props.RectangleoneonMouseOver } onKeyPress={ props.RectangleoneonKeyPress } onDrag={ props.RectangleoneonDrag } onMouseLeave={ props.RectangleoneonMouseLeave } onMouseUp={ props.RectangleoneonMouseUp } onMouseDown={ props.RectangleoneonMouseDown } onKeyDown={ props.RectangleoneonKeyDown } onChange={ props.RectangleoneonChange } ondelay={ props.Rectangleoneondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectangleone']?.animationClass || {}}>
          <div id="id_one_onenigth" className={` rectangle rectangleone ${ props.onClick ? 'cursor' : '' } ${ transaction['rectangleone']?.type ? transaction['rectangleone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.RectangleoneStyle , transitionDuration: transaction['rectangleone']?.duration, transitionTimingFunction: transaction['rectangleone']?.timingFunction }} onClick={ props.RectangleoneonClick } onMouseEnter={ props.RectangleoneonMouseEnter } onMouseOver={ props.RectangleoneonMouseOver } onKeyPress={ props.RectangleoneonKeyPress } onDrag={ props.RectangleoneonDrag } onMouseLeave={ props.RectangleoneonMouseLeave } onMouseUp={ props.RectangleoneonMouseUp } onMouseDown={ props.RectangleoneonMouseDown } onKeyDown={ props.RectangleoneonKeyDown } onChange={ props.RectangleoneonChange } ondelay={ props.Rectangleoneondelay }></div>
        </CSSTransition>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['ingresartexto']?.animationClass || {}}>

          <span id="id_onetwoo_twoozerofour"  className={` text ingresartexto    ${ props.onClick ? 'cursor' : ''}  ${ transaction['ingresartexto']?.type ? transaction['ingresartexto']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.IngresartextoStyle , transitionDuration: transaction['ingresartexto']?.duration, transitionTimingFunction: transaction['ingresartexto']?.timingFunction }} onClick={ props.IngresartextoonClick } onMouseEnter={ props.IngresartextoonMouseEnter } onMouseOver={ props.IngresartextoonMouseOver } onKeyPress={ props.IngresartextoonKeyPress } onDrag={ props.IngresartextoonDrag } onMouseLeave={ props.IngresartextoonMouseLeave } onMouseUp={ props.IngresartextoonMouseUp } onMouseDown={ props.IngresartextoonMouseDown } onKeyDown={ props.IngresartextoonKeyDown } onChange={ props.IngresartextoonChange } ondelay={ props.Ingresartextoondelay } >{props.Ingresartexto0 || `Ingresar texto`}</span>

        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Rectangleone.propTypes = {
    style: PropTypes.any,
Rectangleone0: PropTypes.any,
Ingresartexto0: PropTypes.any,
RectangleoneonClick: PropTypes.any,
RectangleoneonMouseEnter: PropTypes.any,
RectangleoneonMouseOver: PropTypes.any,
RectangleoneonKeyPress: PropTypes.any,
RectangleoneonDrag: PropTypes.any,
RectangleoneonMouseLeave: PropTypes.any,
RectangleoneonMouseUp: PropTypes.any,
RectangleoneonMouseDown: PropTypes.any,
RectangleoneonKeyDown: PropTypes.any,
RectangleoneonChange: PropTypes.any,
Rectangleoneondelay: PropTypes.any,
IngresartextoonClick: PropTypes.any,
IngresartextoonMouseEnter: PropTypes.any,
IngresartextoonMouseOver: PropTypes.any,
IngresartextoonKeyPress: PropTypes.any,
IngresartextoonDrag: PropTypes.any,
IngresartextoonMouseLeave: PropTypes.any,
IngresartextoonMouseUp: PropTypes.any,
IngresartextoonMouseDown: PropTypes.any,
IngresartextoonKeyDown: PropTypes.any,
IngresartextoonChange: PropTypes.any,
Ingresartextoondelay: PropTypes.any
}
export default Rectangleone;