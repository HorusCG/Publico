import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Frametwoofive.css'





const Frametwoofive = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frametwoofive']?.animationClass || {}}>

    <div id="id_sixthree_twooeightfive" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } frametwoofive C_sixthree_twooeightfive ${ props.cssClass } ${ transaction['frametwoofive']?.type ? transaction['frametwoofive']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['frametwoofive']?.duration, transitionTimingFunction: transaction['frametwoofive']?.timingFunction }, ...props.style }} onClick={ props.FrametwoofiveonClick } onMouseEnter={ props.FrametwoofiveonMouseEnter } onMouseOver={ props.FrametwoofiveonMouseOver } onKeyPress={ props.FrametwoofiveonKeyPress } onDrag={ props.FrametwoofiveonDrag } onMouseLeave={ props.FrametwoofiveonMouseLeave } onMouseUp={ props.FrametwoofiveonMouseUp } onMouseDown={ props.FrametwoofiveonMouseDown } onKeyDown={ props.FrametwoofiveonKeyDown } onChange={ props.FrametwoofiveonChange } ondelay={ props.Frametwoofiveondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frametwooseven']?.animationClass || {}}>

          <div id="id_sixthree_twoosixseven" className={` frame frametwooseven ${ props.onClick ? 'cursor' : '' } ${ transaction['frametwooseven']?.type ? transaction['frametwooseven']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrametwoosevenStyle , transitionDuration: transaction['frametwooseven']?.duration, transitionTimingFunction: transaction['frametwooseven']?.timingFunction } } onClick={ props.FrametwoosevenonClick } onMouseEnter={ props.FrametwoosevenonMouseEnter } onMouseOver={ props.FrametwoosevenonMouseOver } onKeyPress={ props.FrametwoosevenonKeyPress } onDrag={ props.FrametwoosevenonDrag } onMouseLeave={ props.FrametwoosevenonMouseLeave } onMouseUp={ props.FrametwoosevenonMouseUp } onMouseDown={ props.FrametwoosevenonMouseDown } onKeyDown={ props.FrametwoosevenonKeyDown } onChange={ props.FrametwoosevenonChange } ondelay={ props.Frametwoosevenondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.animationClass || {}}>
              <img id="id_sixthree_twoosixeight" className={` rectangle imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.timingFunction }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneondelay } src={props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/e59c03e3ad6cd99062c4391243b9c7e2c3c47b6e.png" } />
            </CSSTransition>
          </div>

        </CSSTransition>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['frametwooeight']?.animationClass || {}}>

          <div id="id_onezerozero_eighteightone" className={` frame frametwooeight ${ props.onClick ? 'cursor' : '' } ${ transaction['frametwooeight']?.type ? transaction['frametwooeight']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.FrametwooeightStyle , transitionDuration: transaction['frametwooeight']?.duration, transitionTimingFunction: transaction['frametwooeight']?.timingFunction } } onClick={ props.FrametwooeightonClick } onMouseEnter={ props.FrametwooeightonMouseEnter } onMouseOver={ props.FrametwooeightonMouseOver } onKeyPress={ props.FrametwooeightonKeyPress } onDrag={ props.FrametwooeightonDrag } onMouseLeave={ props.FrametwooeightonMouseLeave } onMouseUp={ props.FrametwooeightonMouseUp } onMouseDown={ props.FrametwooeightonMouseDown } onKeyDown={ props.FrametwooeightonKeyDown } onChange={ props.FrametwooeightonChange } ondelay={ props.Frametwooeightondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['heyhazmeclicksitienesalgunaduda']?.animationClass || {}}>

              <span id="id_onezerozero_eighteighttwoo"  className={` text heyhazmeclicksitienesalgunaduda    ${ props.onClick ? 'cursor' : ''}  ${ transaction['heyhazmeclicksitienesalgunaduda']?.type ? transaction['heyhazmeclicksitienesalgunaduda']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.HeyhazmeclicksitienesalgunadudaStyle , transitionDuration: transaction['heyhazmeclicksitienesalgunaduda']?.duration, transitionTimingFunction: transaction['heyhazmeclicksitienesalgunaduda']?.timingFunction }} onClick={ props.HeyhazmeclicksitienesalgunadudaonClick } onMouseEnter={ props.HeyhazmeclicksitienesalgunadudaonMouseEnter } onMouseOver={ props.HeyhazmeclicksitienesalgunadudaonMouseOver } onKeyPress={ props.HeyhazmeclicksitienesalgunadudaonKeyPress } onDrag={ props.HeyhazmeclicksitienesalgunadudaonDrag } onMouseLeave={ props.HeyhazmeclicksitienesalgunadudaonMouseLeave } onMouseUp={ props.HeyhazmeclicksitienesalgunadudaonMouseUp } onMouseDown={ props.HeyhazmeclicksitienesalgunadudaonMouseDown } onKeyDown={ props.HeyhazmeclicksitienesalgunadudaonKeyDown } onChange={ props.HeyhazmeclicksitienesalgunadudaonChange } ondelay={ props.Heyhazmeclicksitienesalgunadudaondelay } >{props.Heyhazmeclicksitienesalgunaduda0 || `Hey!!! hazme click si tienes alguna duda 😁`}</span>

            </CSSTransition>
          </div>

        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Frametwoofive.propTypes = {
    style: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone0: PropTypes.any,
Heyhazmeclicksitienesalgunaduda0: PropTypes.any,
FrametwoofiveonClick: PropTypes.any,
FrametwoofiveonMouseEnter: PropTypes.any,
FrametwoofiveonMouseOver: PropTypes.any,
FrametwoofiveonKeyPress: PropTypes.any,
FrametwoofiveonDrag: PropTypes.any,
FrametwoofiveonMouseLeave: PropTypes.any,
FrametwoofiveonMouseUp: PropTypes.any,
FrametwoofiveonMouseDown: PropTypes.any,
FrametwoofiveonKeyDown: PropTypes.any,
FrametwoofiveonChange: PropTypes.any,
Frametwoofiveondelay: PropTypes.any,
FrametwoosevenonClick: PropTypes.any,
FrametwoosevenonMouseEnter: PropTypes.any,
FrametwoosevenonMouseOver: PropTypes.any,
FrametwoosevenonKeyPress: PropTypes.any,
FrametwoosevenonDrag: PropTypes.any,
FrametwoosevenonMouseLeave: PropTypes.any,
FrametwoosevenonMouseUp: PropTypes.any,
FrametwoosevenonMouseDown: PropTypes.any,
FrametwoosevenonKeyDown: PropTypes.any,
FrametwoosevenonChange: PropTypes.any,
Frametwoosevenondelay: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonClick: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseEnter: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseOver: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyPress: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonDrag: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseLeave: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseUp: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonChange: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneondelay: PropTypes.any,
FrametwooeightonClick: PropTypes.any,
FrametwooeightonMouseEnter: PropTypes.any,
FrametwooeightonMouseOver: PropTypes.any,
FrametwooeightonKeyPress: PropTypes.any,
FrametwooeightonDrag: PropTypes.any,
FrametwooeightonMouseLeave: PropTypes.any,
FrametwooeightonMouseUp: PropTypes.any,
FrametwooeightonMouseDown: PropTypes.any,
FrametwooeightonKeyDown: PropTypes.any,
FrametwooeightonChange: PropTypes.any,
Frametwooeightondelay: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonClick: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonMouseEnter: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonMouseOver: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonKeyPress: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonDrag: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonMouseLeave: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonMouseUp: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonMouseDown: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonKeyDown: PropTypes.any,
HeyhazmeclicksitienesalgunadudaonChange: PropTypes.any,
Heyhazmeclicksitienesalgunadudaondelay: PropTypes.any
}
export default Frametwoofive;