import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Buttonforchat.css'





const Buttonforchat = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['buttonforchat']?.animationClass || {}}>

    <div id="id_one_twoo" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } buttonforchat ${ props.cssClass } ${ transaction['buttonforchat']?.type ? transaction['buttonforchat']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['buttonforchat']?.duration, transitionTimingFunction: transaction['buttonforchat']?.timingFunction }, ...props.style }} onClick={ props.ButtonforchatonClick } onMouseEnter={ props.ButtonforchatonMouseEnter } onMouseOver={ props.ButtonforchatonMouseOver } onKeyPress={ props.ButtonforchatonKeyPress } onDrag={ props.ButtonforchatonDrag } onMouseLeave={ props.ButtonforchatonMouseLeave } onMouseUp={ props.ButtonforchatonMouseUp } onMouseDown={ props.ButtonforchatonMouseDown } onKeyDown={ props.ButtonforchatonKeyDown } onChange={ props.ButtonforchatonChange } ondelay={ props.Buttonforchatondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.animationClass || {}}>
          <img id="id_twoo_eight" className={` rectangle imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone ${ props.onClick ? 'cursor' : '' } ${ transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.type ? transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneStyle , transitionDuration: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.duration, transitionTimingFunction: transaction['imagendewhatsapptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone']?.timingFunction }} onClick={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonClick } onMouseEnter={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseEnter } onMouseOver={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseOver } onKeyPress={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyPress } onDrag={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonDrag } onMouseLeave={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseLeave } onMouseUp={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseUp } onMouseDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseDown } onKeyDown={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyDown } onChange={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonChange } ondelay={ props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneondelay } src={props.ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone0 || "https://cdn.uncodie.com/UjIHmrgTScgfxn4h0DZIym/e59c03e3ad6cd99062c4391243b9c7e2c3c47b6e.png" } />
        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Buttonforchat.propTypes = {
    style: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone0: PropTypes.any,
ButtonforchatonClick: PropTypes.any,
ButtonforchatonMouseEnter: PropTypes.any,
ButtonforchatonMouseOver: PropTypes.any,
ButtonforchatonKeyPress: PropTypes.any,
ButtonforchatonDrag: PropTypes.any,
ButtonforchatonMouseLeave: PropTypes.any,
ButtonforchatonMouseUp: PropTypes.any,
ButtonforchatonMouseDown: PropTypes.any,
ButtonforchatonKeyDown: PropTypes.any,
ButtonforchatonChange: PropTypes.any,
Buttonforchatondelay: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonClick: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseEnter: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseOver: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyPress: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonDrag: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseLeave: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseUp: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyDown: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonChange: PropTypes.any,
ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneondelay: PropTypes.any
}
export default Buttonforchat;