import React, { Suspense } from 'react';
import PropTypes from 'prop-types';
import * as Contexts  from '../Contexts.js';



import * as UtilsScripts  from '../../utils/utils';

import LoadingComponent from "../../components/Loading";


import { Transition } from "react-transition-group";
import { CSSTransition } from "react-transition-group";
import './Rectangletwoo.css'





const Rectangletwoo = (props)=>{
    
    
    
    const nodeRef = React.useRef(null);
    
    
    
    
    
    
    
    
    
    const [ _in, setIn ] = React.useState(false)
    const [ transaction, setTransaction ] = React.useState({}) 
    const [ animation, setAnimation ] = React.useState('')

    
    
    
    
    
    
    React.useEffect(()=>{
        
        
        
    },[]);
    
    
    return (
        <>
  <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectangletwoo']?.animationClass || {}}>

    <div id="id_foureight_threesixfive" ref={nodeRef} className={` ${ props.onClick ? 'cursor' : '' } rectangletwoo C_foureight_threesixfive ${ props.cssClass } ${ transaction['rectangletwoo']?.type ? transaction['rectangletwoo']?.type.toLowerCase() : '' }`} style={ { ...{ ...{}, transitionDuration: transaction['rectangletwoo']?.duration, transitionTimingFunction: transaction['rectangletwoo']?.timingFunction }, ...props.style }} onClick={ props.RectangletwooonClick } onMouseEnter={ props.RectangletwooonMouseEnter } onMouseOver={ props.RectangletwooonMouseOver } onKeyPress={ props.RectangletwooonKeyPress } onDrag={ props.RectangletwooonDrag } onMouseLeave={ props.RectangletwooonMouseLeave } onMouseUp={ props.RectangletwooonMouseUp } onMouseDown={ props.RectangletwooonMouseDown } onKeyDown={ props.RectangletwooonKeyDown } onChange={ props.RectangletwooonChange } ondelay={ props.Rectangletwooondelay }>
      {
      props.children ?
      props.children :
      <>
        <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectangletwoo']?.animationClass || {}}>

          <div id="id_onezerozero_nigthtwoofive" className={` frame rectangletwoo ${ props.onClick ? 'cursor' : '' } ${ transaction['rectangletwoo']?.type ? transaction['rectangletwoo']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.RectangletwooStyle , transitionDuration: transaction['rectangletwoo']?.duration, transitionTimingFunction: transaction['rectangletwoo']?.timingFunction } } onClick={ props.RectangletwooonClick } onMouseEnter={ props.RectangletwooonMouseEnter } onMouseOver={ props.RectangletwooonMouseOver } onKeyPress={ props.RectangletwooonKeyPress } onDrag={ props.RectangletwooonDrag } onMouseLeave={ props.RectangletwooonMouseLeave } onMouseUp={ props.RectangletwooonMouseUp } onMouseDown={ props.RectangletwooonMouseDown } onKeyDown={ props.RectangletwooonKeyDown } onChange={ props.RectangletwooonChange } ondelay={ props.Rectangletwooondelay }>
            <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectangletwoo']?.animationClass || {}}>

              <div id="id_onezerozero_nigthtwoosix" className={` frame rectangletwoo ${ props.onClick ? 'cursor' : '' } ${ transaction['rectangletwoo']?.type ? transaction['rectangletwoo']?.type.toLowerCase() : '' }`} style={ { ...{}, ...props.RectangletwooStyle , transitionDuration: transaction['rectangletwoo']?.duration, transitionTimingFunction: transaction['rectangletwoo']?.timingFunction } } onClick={ props.RectangletwooonClick } onMouseEnter={ props.RectangletwooonMouseEnter } onMouseOver={ props.RectangletwooonMouseOver } onKeyPress={ props.RectangletwooonKeyPress } onDrag={ props.RectangletwooonDrag } onMouseLeave={ props.RectangletwooonMouseLeave } onMouseUp={ props.RectangletwooonMouseUp } onMouseDown={ props.RectangletwooonMouseDown } onKeyDown={ props.RectangletwooonKeyDown } onChange={ props.RectangletwooonChange } ondelay={ props.Rectangletwooondelay }>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['rectangletwoo']?.animationClass || {}}>
                  <div id="id_onezerozero_nigthtwooseven" className={` rectangle rectangletwoo ${ props.onClick ? 'cursor' : '' } ${ transaction['rectangletwoo']?.type ? transaction['rectangletwoo']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.RectangletwooStyle , transitionDuration: transaction['rectangletwoo']?.duration, transitionTimingFunction: transaction['rectangletwoo']?.timingFunction }} onClick={ props.RectangletwooonClick } onMouseEnter={ props.RectangletwooonMouseEnter } onMouseOver={ props.RectangletwooonMouseOver } onKeyPress={ props.RectangletwooonKeyPress } onDrag={ props.RectangletwooonDrag } onMouseLeave={ props.RectangletwooonMouseLeave } onMouseUp={ props.RectangletwooonMouseUp } onMouseDown={ props.RectangletwooonMouseDown } onKeyDown={ props.RectangletwooonKeyDown } onChange={ props.RectangletwooonChange } ondelay={ props.Rectangletwooondelay }></div>
                </CSSTransition>
                <CSSTransition in={_in} appear={true} timeout={100} classNames={transaction['ingresartexto']?.animationClass || {}}>

                  <span id="id_onezerozero_nigthtwooeight"  className={` text ingresartexto    ${ props.onClick ? 'cursor' : ''}  ${ transaction['ingresartexto']?.type ? transaction['ingresartexto']?.type.toLowerCase() : '' }`} style={{ ...{},  ...props.IngresartextoStyle , transitionDuration: transaction['ingresartexto']?.duration, transitionTimingFunction: transaction['ingresartexto']?.timingFunction }} onClick={ props.IngresartextoonClick } onMouseEnter={ props.IngresartextoonMouseEnter } onMouseOver={ props.IngresartextoonMouseOver } onKeyPress={ props.IngresartextoonKeyPress } onDrag={ props.IngresartextoonDrag } onMouseLeave={ props.IngresartextoonMouseLeave } onMouseUp={ props.IngresartextoonMouseUp } onMouseDown={ props.IngresartextoonMouseDown } onKeyDown={ props.IngresartextoonKeyDown } onChange={ props.IngresartextoonChange } ondelay={ props.Ingresartextoondelay } >{props.Ingresartexto0 || `Ingresar texto`}</span>

                </CSSTransition>
              </div>

            </CSSTransition>
          </div>

        </CSSTransition>

      </>
      }
    </div>

  </CSSTransition>
</>
    ) 
}

Rectangletwoo.propTypes = {
    style: PropTypes.any,
Rectangletwoo0: PropTypes.any,
Ingresartexto0: PropTypes.any,
RectangletwooonClick: PropTypes.any,
RectangletwooonMouseEnter: PropTypes.any,
RectangletwooonMouseOver: PropTypes.any,
RectangletwooonKeyPress: PropTypes.any,
RectangletwooonDrag: PropTypes.any,
RectangletwooonMouseLeave: PropTypes.any,
RectangletwooonMouseUp: PropTypes.any,
RectangletwooonMouseDown: PropTypes.any,
RectangletwooonKeyDown: PropTypes.any,
RectangletwooonChange: PropTypes.any,
Rectangletwooondelay: PropTypes.any,
IngresartextoonClick: PropTypes.any,
IngresartextoonMouseEnter: PropTypes.any,
IngresartextoonMouseOver: PropTypes.any,
IngresartextoonKeyPress: PropTypes.any,
IngresartextoonDrag: PropTypes.any,
IngresartextoonMouseLeave: PropTypes.any,
IngresartextoonMouseUp: PropTypes.any,
IngresartextoonMouseDown: PropTypes.any,
IngresartextoonKeyDown: PropTypes.any,
IngresartextoonChange: PropTypes.any,
Ingresartextoondelay: PropTypes.any
}
export default Rectangletwoo;