import React from "react";
import { Rectangleone } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Rectangleone",
  component: Rectangleone,
  argTypes: {
    
  },
} as ComponentMeta<typeof Rectangleone>;

const Template: ComponentStory<typeof Rectangleone> = (args: any) => (
    <OverlaySwapProvider>
        <Rectangleone {...args} />
    </OverlaySwapProvider>
);

export const RectangleoneTemplate = Template.bind({});

RectangleoneTemplate.args = {};