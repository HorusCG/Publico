import React from "react";
import { Rectangletwoo } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Rectangletwoo",
  component: Rectangletwoo,
  argTypes: {
    
  },
} as ComponentMeta<typeof Rectangletwoo>;

const Template: ComponentStory<typeof Rectangletwoo> = (args: any) => (
    <OverlaySwapProvider>
        <Rectangletwoo {...args} />
    </OverlaySwapProvider>
);

export const RectangletwooTemplate = Template.bind({});

RectangletwooTemplate.args = {};