import React from "react";
import { Jovenseguroauto } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Jovenseguroauto",
  component: Jovenseguroauto,
  argTypes: {
    
  },
} as ComponentMeta<typeof Jovenseguroauto>;

const Template: ComponentStory<typeof Jovenseguroauto> = (args: any) => (
    <OverlaySwapProvider>
        <Jovenseguroauto {...args} />
    </OverlaySwapProvider>
);

export const JovenseguroautoTemplate = Template.bind({});

JovenseguroautoTemplate.args = {};