import React from "react";
import { Grandesseguro } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Grandesseguro",
  component: Grandesseguro,
  argTypes: {
    
  },
} as ComponentMeta<typeof Grandesseguro>;

const Template: ComponentStory<typeof Grandesseguro> = (args: any) => (
    <OverlaySwapProvider>
        <Grandesseguro {...args} />
    </OverlaySwapProvider>
);

export const GrandesseguroTemplate = Template.bind({});

GrandesseguroTemplate.args = {};