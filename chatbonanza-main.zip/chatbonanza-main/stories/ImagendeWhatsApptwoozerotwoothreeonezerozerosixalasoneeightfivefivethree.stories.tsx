import React from "react";
import { ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree",
  component: ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree,
  argTypes: {
    
  },
} as ComponentMeta<typeof ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree>;

const Template: ComponentStory<typeof ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree> = (args: any) => (
    <OverlaySwapProvider>
        <ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree {...args} />
    </OverlaySwapProvider>
);

export const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeTemplate = Template.bind({});

ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeTemplate.args = {};