import React from "react";
import { Buttonforchatthreeonethreeeight } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Buttonforchatthreeonethreeeight",
  component: Buttonforchatthreeonethreeeight,
  argTypes: {
    
  },
} as ComponentMeta<typeof Buttonforchatthreeonethreeeight>;

const Template: ComponentStory<typeof Buttonforchatthreeonethreeeight> = (args: any) => (
    <OverlaySwapProvider>
        <Buttonforchatthreeonethreeeight {...args} />
    </OverlaySwapProvider>
);

export const ButtonforchatthreeonethreeeightTemplate = Template.bind({});

ButtonforchatthreeonethreeeightTemplate.args = {};