import React from "react";
import { Apoyoconocimientomedianos } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Apoyoconocimientomedianos",
  component: Apoyoconocimientomedianos,
  argTypes: {
    
  },
} as ComponentMeta<typeof Apoyoconocimientomedianos>;

const Template: ComponentStory<typeof Apoyoconocimientomedianos> = (args: any) => (
    <OverlaySwapProvider>
        <Apoyoconocimientomedianos {...args} />
    </OverlaySwapProvider>
);

export const ApoyoconocimientomedianosTemplate = Template.bind({});

ApoyoconocimientomedianosTemplate.args = {};