import React from "react";
import { Buttonforchattwoothreethreezero } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Buttonforchattwoothreethreezero",
  component: Buttonforchattwoothreethreezero,
  argTypes: {
    
  },
} as ComponentMeta<typeof Buttonforchattwoothreethreezero>;

const Template: ComponentStory<typeof Buttonforchattwoothreethreezero> = (args: any) => (
    <OverlaySwapProvider>
        <Buttonforchattwoothreethreezero {...args} />
    </OverlaySwapProvider>
);

export const ButtonforchattwoothreethreezeroTemplate = Template.bind({});

ButtonforchattwoothreethreezeroTemplate.args = {};