import React from "react";
import { Solucionahorromediano } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Solucionahorromediano",
  component: Solucionahorromediano,
  argTypes: {
    
  },
} as ComponentMeta<typeof Solucionahorromediano>;

const Template: ComponentStory<typeof Solucionahorromediano> = (args: any) => (
    <OverlaySwapProvider>
        <Solucionahorromediano {...args} />
    </OverlaySwapProvider>
);

export const SolucionahorromedianoTemplate = Template.bind({});

SolucionahorromedianoTemplate.args = {};