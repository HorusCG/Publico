import React from "react";
import { Rectanglefour } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Rectanglefour",
  component: Rectanglefour,
  argTypes: {
    
  },
} as ComponentMeta<typeof Rectanglefour>;

const Template: ComponentStory<typeof Rectanglefour> = (args: any) => (
    <OverlaySwapProvider>
        <Rectanglefour {...args} />
    </OverlaySwapProvider>
);

export const RectanglefourTemplate = Template.bind({});

RectanglefourTemplate.args = {};