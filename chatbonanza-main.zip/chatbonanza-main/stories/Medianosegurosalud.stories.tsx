import React from "react";
import { Medianosegurosalud } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Medianosegurosalud",
  component: Medianosegurosalud,
  argTypes: {
    
  },
} as ComponentMeta<typeof Medianosegurosalud>;

const Template: ComponentStory<typeof Medianosegurosalud> = (args: any) => (
    <OverlaySwapProvider>
        <Medianosegurosalud {...args} />
    </OverlaySwapProvider>
);

export const MedianosegurosaludTemplate = Template.bind({});

MedianosegurosaludTemplate.args = {};