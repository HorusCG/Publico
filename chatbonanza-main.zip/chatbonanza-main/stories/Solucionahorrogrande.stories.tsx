import React from "react";
import { Solucionahorrogrande } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Solucionahorrogrande",
  component: Solucionahorrogrande,
  argTypes: {
    
  },
} as ComponentMeta<typeof Solucionahorrogrande>;

const Template: ComponentStory<typeof Solucionahorrogrande> = (args: any) => (
    <OverlaySwapProvider>
        <Solucionahorrogrande {...args} />
    </OverlaySwapProvider>
);

export const SolucionahorrograndeTemplate = Template.bind({});

SolucionahorrograndeTemplate.args = {};