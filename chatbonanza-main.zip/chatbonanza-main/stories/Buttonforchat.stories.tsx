import React from "react";
import { Buttonforchat } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Buttonforchat",
  component: Buttonforchat,
  argTypes: {
    
  },
} as ComponentMeta<typeof Buttonforchat>;

const Template: ComponentStory<typeof Buttonforchat> = (args: any) => (
    <OverlaySwapProvider>
        <Buttonforchat {...args} />
    </OverlaySwapProvider>
);

export const ButtonforchatTemplate = Template.bind({});

ButtonforchatTemplate.args = {};