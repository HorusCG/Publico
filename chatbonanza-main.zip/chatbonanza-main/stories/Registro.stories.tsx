import React from "react";
import { Registro } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Registro",
  component: Registro,
  argTypes: {
    
  },
} as ComponentMeta<typeof Registro>;

const Template: ComponentStory<typeof Registro> = (args: any) => (
    <OverlaySwapProvider>
        <Registro {...args} />
    </OverlaySwapProvider>
);

export const RegistroTemplate = Template.bind({});

RegistroTemplate.args = {};