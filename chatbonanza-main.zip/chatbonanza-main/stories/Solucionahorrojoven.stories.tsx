import React from "react";
import { Solucionahorrojoven } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Solucionahorrojoven",
  component: Solucionahorrojoven,
  argTypes: {
    
  },
} as ComponentMeta<typeof Solucionahorrojoven>;

const Template: ComponentStory<typeof Solucionahorrojoven> = (args: any) => (
    <OverlaySwapProvider>
        <Solucionahorrojoven {...args} />
    </OverlaySwapProvider>
);

export const SolucionahorrojovenTemplate = Template.bind({});

SolucionahorrojovenTemplate.args = {};