import React from "react";
import { Menuoneeighttwootwoo } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Menuoneeighttwootwoo",
  component: Menuoneeighttwootwoo,
  argTypes: {
    
  },
} as ComponentMeta<typeof Menuoneeighttwootwoo>;

const Template: ComponentStory<typeof Menuoneeighttwootwoo> = (args: any) => (
    <OverlaySwapProvider>
        <Menuoneeighttwootwoo {...args} />
    </OverlaySwapProvider>
);

export const MenuoneeighttwootwooTemplate = Template.bind({});

MenuoneeighttwootwooTemplate.args = {};