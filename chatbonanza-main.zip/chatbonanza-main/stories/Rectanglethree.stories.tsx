import React from "react";
import { Rectanglethree } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Rectanglethree",
  component: Rectanglethree,
  argTypes: {
    
  },
} as ComponentMeta<typeof Rectanglethree>;

const Template: ComponentStory<typeof Rectanglethree> = (args: any) => (
    <OverlaySwapProvider>
        <Rectanglethree {...args} />
    </OverlaySwapProvider>
);

export const RectanglethreeTemplate = Template.bind({});

RectanglethreeTemplate.args = {};