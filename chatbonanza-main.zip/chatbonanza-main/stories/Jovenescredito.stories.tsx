import React from "react";
import { Jovenescredito } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Jovenescredito",
  component: Jovenescredito,
  argTypes: {
    
  },
} as ComponentMeta<typeof Jovenescredito>;

const Template: ComponentStory<typeof Jovenescredito> = (args: any) => (
    <OverlaySwapProvider>
        <Jovenescredito {...args} />
    </OverlaySwapProvider>
);

export const JovenescreditoTemplate = Template.bind({});

JovenescreditoTemplate.args = {};