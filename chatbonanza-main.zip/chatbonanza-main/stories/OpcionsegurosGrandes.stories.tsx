import React from "react";
import { OpcionsegurosGrandes } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/OpcionsegurosGrandes",
  component: OpcionsegurosGrandes,
  argTypes: {
    
  },
} as ComponentMeta<typeof OpcionsegurosGrandes>;

const Template: ComponentStory<typeof OpcionsegurosGrandes> = (args: any) => (
    <OverlaySwapProvider>
        <OpcionsegurosGrandes {...args} />
    </OverlaySwapProvider>
);

export const OpcionsegurosGrandesTemplate = Template.bind({});

OpcionsegurosGrandesTemplate.args = {};