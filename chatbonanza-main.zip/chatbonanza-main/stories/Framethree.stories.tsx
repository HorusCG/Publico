import React from "react";
import { Framethree } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Framethree",
  component: Framethree,
  argTypes: {
    
  },
} as ComponentMeta<typeof Framethree>;

const Template: ComponentStory<typeof Framethree> = (args: any) => (
    <OverlaySwapProvider>
        <Framethree {...args} />
    </OverlaySwapProvider>
);

export const FramethreeTemplate = Template.bind({});

FramethreeTemplate.args = {};