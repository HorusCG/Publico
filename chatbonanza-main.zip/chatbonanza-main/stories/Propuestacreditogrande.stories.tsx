import React from "react";
import { Propuestacreditogrande } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Propuestacreditogrande",
  component: Propuestacreditogrande,
  argTypes: {
    
  },
} as ComponentMeta<typeof Propuestacreditogrande>;

const Template: ComponentStory<typeof Propuestacreditogrande> = (args: any) => (
    <OverlaySwapProvider>
        <Propuestacreditogrande {...args} />
    </OverlaySwapProvider>
);

export const PropuestacreditograndeTemplate = Template.bind({});

PropuestacreditograndeTemplate.args = {};