import React from "react";
import { Jovenesseguro } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Jovenesseguro",
  component: Jovenesseguro,
  argTypes: {
    
  },
} as ComponentMeta<typeof Jovenesseguro>;

const Template: ComponentStory<typeof Jovenesseguro> = (args: any) => (
    <OverlaySwapProvider>
        <Jovenesseguro {...args} />
    </OverlaySwapProvider>
);

export const JovenesseguroTemplate = Template.bind({});

JovenesseguroTemplate.args = {};