import React from "react";
import { ObjetivoJovenes } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/ObjetivoJovenes",
  component: ObjetivoJovenes,
  argTypes: {
    
  },
} as ComponentMeta<typeof ObjetivoJovenes>;

const Template: ComponentStory<typeof ObjetivoJovenes> = (args: any) => (
    <OverlaySwapProvider>
        <ObjetivoJovenes {...args} />
    </OverlaySwapProvider>
);

export const ObjetivoJovenesTemplate = Template.bind({});

ObjetivoJovenesTemplate.args = {};