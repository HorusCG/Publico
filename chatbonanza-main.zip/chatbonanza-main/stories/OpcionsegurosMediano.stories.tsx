import React from "react";
import { OpcionsegurosMediano } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/OpcionsegurosMediano",
  component: OpcionsegurosMediano,
  argTypes: {
    
  },
} as ComponentMeta<typeof OpcionsegurosMediano>;

const Template: ComponentStory<typeof OpcionsegurosMediano> = (args: any) => (
    <OverlaySwapProvider>
        <OpcionsegurosMediano {...args} />
    </OverlaySwapProvider>
);

export const OpcionsegurosMedianoTemplate = Template.bind({});

OpcionsegurosMedianoTemplate.args = {};