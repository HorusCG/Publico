import React from "react";
import { ObjetivoGrandes } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/ObjetivoGrandes",
  component: ObjetivoGrandes,
  argTypes: {
    
  },
} as ComponentMeta<typeof ObjetivoGrandes>;

const Template: ComponentStory<typeof ObjetivoGrandes> = (args: any) => (
    <OverlaySwapProvider>
        <ObjetivoGrandes {...args} />
    </OverlaySwapProvider>
);

export const ObjetivoGrandesTemplate = Template.bind({});

ObjetivoGrandesTemplate.args = {};