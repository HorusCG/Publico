import React from "react";
import { JovenesAhorro } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/JovenesAhorro",
  component: JovenesAhorro,
  argTypes: {
    
  },
} as ComponentMeta<typeof JovenesAhorro>;

const Template: ComponentStory<typeof JovenesAhorro> = (args: any) => (
    <OverlaySwapProvider>
        <JovenesAhorro {...args} />
    </OverlaySwapProvider>
);

export const JovenesAhorroTemplate = Template.bind({});

JovenesAhorroTemplate.args = {};