import React from "react";
import { GrandesAhorro } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/GrandesAhorro",
  component: GrandesAhorro,
  argTypes: {
    
  },
} as ComponentMeta<typeof GrandesAhorro>;

const Template: ComponentStory<typeof GrandesAhorro> = (args: any) => (
    <OverlaySwapProvider>
        <GrandesAhorro {...args} />
    </OverlaySwapProvider>
);

export const GrandesAhorroTemplate = Template.bind({});

GrandesAhorroTemplate.args = {};