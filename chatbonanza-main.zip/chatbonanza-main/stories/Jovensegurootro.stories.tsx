import React from "react";
import { Jovensegurootro } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Jovensegurootro",
  component: Jovensegurootro,
  argTypes: {
    
  },
} as ComponentMeta<typeof Jovensegurootro>;

const Template: ComponentStory<typeof Jovensegurootro> = (args: any) => (
    <OverlaySwapProvider>
        <Jovensegurootro {...args} />
    </OverlaySwapProvider>
);

export const JovensegurootroTemplate = Template.bind({});

JovensegurootroTemplate.args = {};