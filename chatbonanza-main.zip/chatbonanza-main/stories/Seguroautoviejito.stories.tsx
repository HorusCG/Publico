import React from "react";
import { Seguroautoviejito } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Seguroautoviejito",
  component: Seguroautoviejito,
  argTypes: {
    
  },
} as ComponentMeta<typeof Seguroautoviejito>;

const Template: ComponentStory<typeof Seguroautoviejito> = (args: any) => (
    <OverlaySwapProvider>
        <Seguroautoviejito {...args} />
    </OverlaySwapProvider>
);

export const SeguroautoviejitoTemplate = Template.bind({});

SeguroautoviejitoTemplate.args = {};