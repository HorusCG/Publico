import React from "react";
import { Apoyoenconocimientojovenes } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Apoyoenconocimientojovenes",
  component: Apoyoenconocimientojovenes,
  argTypes: {
    
  },
} as ComponentMeta<typeof Apoyoenconocimientojovenes>;

const Template: ComponentStory<typeof Apoyoenconocimientojovenes> = (args: any) => (
    <OverlaySwapProvider>
        <Apoyoenconocimientojovenes {...args} />
    </OverlaySwapProvider>
);

export const ApoyoenconocimientojovenesTemplate = Template.bind({});

ApoyoenconocimientojovenesTemplate.args = {};