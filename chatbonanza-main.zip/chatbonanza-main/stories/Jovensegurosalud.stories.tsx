import React from "react";
import { Jovensegurosalud } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Jovensegurosalud",
  component: Jovensegurosalud,
  argTypes: {
    
  },
} as ComponentMeta<typeof Jovensegurosalud>;

const Template: ComponentStory<typeof Jovensegurosalud> = (args: any) => (
    <OverlaySwapProvider>
        <Jovensegurosalud {...args} />
    </OverlaySwapProvider>
);

export const JovensegurosaludTemplate = Template.bind({});

JovensegurosaludTemplate.args = {};