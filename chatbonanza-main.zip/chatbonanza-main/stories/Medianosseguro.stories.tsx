import React from "react";
import { Medianosseguro } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Medianosseguro",
  component: Medianosseguro,
  argTypes: {
    
  },
} as ComponentMeta<typeof Medianosseguro>;

const Template: ComponentStory<typeof Medianosseguro> = (args: any) => (
    <OverlaySwapProvider>
        <Medianosseguro {...args} />
    </OverlaySwapProvider>
);

export const MedianosseguroTemplate = Template.bind({});

MedianosseguroTemplate.args = {};