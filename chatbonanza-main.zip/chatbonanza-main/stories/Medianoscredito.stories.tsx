import React from "react";
import { Medianoscredito } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Medianoscredito",
  component: Medianoscredito,
  argTypes: {
    
  },
} as ComponentMeta<typeof Medianoscredito>;

const Template: ComponentStory<typeof Medianoscredito> = (args: any) => (
    <OverlaySwapProvider>
        <Medianoscredito {...args} />
    </OverlaySwapProvider>
);

export const MedianoscreditoTemplate = Template.bind({});

MedianoscreditoTemplate.args = {};