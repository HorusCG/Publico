import React from "react";
import { Frametwoofive } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Frametwoofive",
  component: Frametwoofive,
  argTypes: {
    
  },
} as ComponentMeta<typeof Frametwoofive>;

const Template: ComponentStory<typeof Frametwoofive> = (args: any) => (
    <OverlaySwapProvider>
        <Frametwoofive {...args} />
    </OverlaySwapProvider>
);

export const FrametwoofiveTemplate = Template.bind({});

FrametwoofiveTemplate.args = {};