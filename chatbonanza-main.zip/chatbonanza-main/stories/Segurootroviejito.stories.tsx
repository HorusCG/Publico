import React from "react";
import { Segurootroviejito } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Segurootroviejito",
  component: Segurootroviejito,
  argTypes: {
    
  },
} as ComponentMeta<typeof Segurootroviejito>;

const Template: ComponentStory<typeof Segurootroviejito> = (args: any) => (
    <OverlaySwapProvider>
        <Segurootroviejito {...args} />
    </OverlaySwapProvider>
);

export const SegurootroviejitoTemplate = Template.bind({});

SegurootroviejitoTemplate.args = {};