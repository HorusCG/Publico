import React from "react";
import { Medianosegurootro } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Medianosegurootro",
  component: Medianosegurootro,
  argTypes: {
    
  },
} as ComponentMeta<typeof Medianosegurootro>;

const Template: ComponentStory<typeof Medianosegurootro> = (args: any) => (
    <OverlaySwapProvider>
        <Medianosegurootro {...args} />
    </OverlaySwapProvider>
);

export const MedianosegurootroTemplate = Template.bind({});

MedianosegurootroTemplate.args = {};