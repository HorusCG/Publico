import React from "react";
import { Menutwoothreethreezero } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Menutwoothreethreezero",
  component: Menutwoothreethreezero,
  argTypes: {
    
  },
} as ComponentMeta<typeof Menutwoothreethreezero>;

const Template: ComponentStory<typeof Menutwoothreethreezero> = (args: any) => (
    <OverlaySwapProvider>
        <Menutwoothreethreezero {...args} />
    </OverlaySwapProvider>
);

export const MenutwoothreethreezeroTemplate = Template.bind({});

MenutwoothreethreezeroTemplate.args = {};