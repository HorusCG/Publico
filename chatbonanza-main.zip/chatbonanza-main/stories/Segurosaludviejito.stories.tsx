import React from "react";
import { Segurosaludviejito } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Segurosaludviejito",
  component: Segurosaludviejito,
  argTypes: {
    
  },
} as ComponentMeta<typeof Segurosaludviejito>;

const Template: ComponentStory<typeof Segurosaludviejito> = (args: any) => (
    <OverlaySwapProvider>
        <Segurosaludviejito {...args} />
    </OverlaySwapProvider>
);

export const SegurosaludviejitoTemplate = Template.bind({});

SegurosaludviejitoTemplate.args = {};