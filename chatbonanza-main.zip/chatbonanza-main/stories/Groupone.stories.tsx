import React from "react";
import { Groupone } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Groupone",
  component: Groupone,
  argTypes: {
    
  },
} as ComponentMeta<typeof Groupone>;

const Template: ComponentStory<typeof Groupone> = (args: any) => (
    <OverlaySwapProvider>
        <Groupone {...args} />
    </OverlaySwapProvider>
);

export const GrouponeTemplate = Template.bind({});

GrouponeTemplate.args = {};