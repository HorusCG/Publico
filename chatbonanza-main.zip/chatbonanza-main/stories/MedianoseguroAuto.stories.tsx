import React from "react";
import { MedianoseguroAuto } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/MedianoseguroAuto",
  component: MedianoseguroAuto,
  argTypes: {
    
  },
} as ComponentMeta<typeof MedianoseguroAuto>;

const Template: ComponentStory<typeof MedianoseguroAuto> = (args: any) => (
    <OverlaySwapProvider>
        <MedianoseguroAuto {...args} />
    </OverlaySwapProvider>
);

export const MedianoseguroAutoTemplate = Template.bind({});

MedianoseguroAutoTemplate.args = {};