import React from "react";
import { Menuthreeone } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Menuthreeone",
  component: Menuthreeone,
  argTypes: {
    
  },
} as ComponentMeta<typeof Menuthreeone>;

const Template: ComponentStory<typeof Menuthreeone> = (args: any) => (
    <OverlaySwapProvider>
        <Menuthreeone {...args} />
    </OverlaySwapProvider>
);

export const MenuthreeoneTemplate = Template.bind({});

MenuthreeoneTemplate.args = {};