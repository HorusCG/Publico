import React from "react";
import { OpcionsegurosJovenes } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/OpcionsegurosJovenes",
  component: OpcionsegurosJovenes,
  argTypes: {
    
  },
} as ComponentMeta<typeof OpcionsegurosJovenes>;

const Template: ComponentStory<typeof OpcionsegurosJovenes> = (args: any) => (
    <OverlaySwapProvider>
        <OpcionsegurosJovenes {...args} />
    </OverlaySwapProvider>
);

export const OpcionsegurosJovenesTemplate = Template.bind({});

OpcionsegurosJovenesTemplate.args = {};