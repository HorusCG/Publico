import React from "react";
import { MedianoAhorro } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/MedianoAhorro",
  component: MedianoAhorro,
  argTypes: {
    
  },
} as ComponentMeta<typeof MedianoAhorro>;

const Template: ComponentStory<typeof MedianoAhorro> = (args: any) => (
    <OverlaySwapProvider>
        <MedianoAhorro {...args} />
    </OverlaySwapProvider>
);

export const MedianoAhorroTemplate = Template.bind({});

MedianoAhorroTemplate.args = {};