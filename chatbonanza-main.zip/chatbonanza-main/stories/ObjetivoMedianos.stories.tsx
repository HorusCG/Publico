import React from "react";
import { ObjetivoMedianos } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/ObjetivoMedianos",
  component: ObjetivoMedianos,
  argTypes: {
    
  },
} as ComponentMeta<typeof ObjetivoMedianos>;

const Template: ComponentStory<typeof ObjetivoMedianos> = (args: any) => (
    <OverlaySwapProvider>
        <ObjetivoMedianos {...args} />
    </OverlaySwapProvider>
);

export const ObjetivoMedianosTemplate = Template.bind({});

ObjetivoMedianosTemplate.args = {};