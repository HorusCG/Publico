import React from "react";
import { Rectanglefive } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Rectanglefive",
  component: Rectanglefive,
  argTypes: {
    
  },
} as ComponentMeta<typeof Rectanglefive>;

const Template: ComponentStory<typeof Rectanglefive> = (args: any) => (
    <OverlaySwapProvider>
        <Rectanglefive {...args} />
    </OverlaySwapProvider>
);

export const RectanglefiveTemplate = Template.bind({});

RectanglefiveTemplate.args = {};