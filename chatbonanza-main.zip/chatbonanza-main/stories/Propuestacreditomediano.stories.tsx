import React from "react";
import { Propuestacreditomediano } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Propuestacreditomediano",
  component: Propuestacreditomediano,
  argTypes: {
    
  },
} as ComponentMeta<typeof Propuestacreditomediano>;

const Template: ComponentStory<typeof Propuestacreditomediano> = (args: any) => (
    <OverlaySwapProvider>
        <Propuestacreditomediano {...args} />
    </OverlaySwapProvider>
);

export const PropuestacreditomedianoTemplate = Template.bind({});

PropuestacreditomedianoTemplate.args = {};