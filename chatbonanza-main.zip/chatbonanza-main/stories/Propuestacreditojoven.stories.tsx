import React from "react";
import { Propuestacreditojoven } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Propuestacreditojoven",
  component: Propuestacreditojoven,
  argTypes: {
    
  },
} as ComponentMeta<typeof Propuestacreditojoven>;

const Template: ComponentStory<typeof Propuestacreditojoven> = (args: any) => (
    <OverlaySwapProvider>
        <Propuestacreditojoven {...args} />
    </OverlaySwapProvider>
);

export const PropuestacreditojovenTemplate = Template.bind({});

PropuestacreditojovenTemplate.args = {};