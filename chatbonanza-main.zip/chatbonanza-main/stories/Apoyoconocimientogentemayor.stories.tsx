import React from "react";
import { Apoyoconocimientogentemayor } from "../components";
import OverlaySwapProvider from "../components/OverlaySwapProvider"
import { action } from "@storybook/addon-actions";
import { ComponentStory, ComponentMeta } from "@storybook/react";

export default {
  title: "Components/Apoyoconocimientogentemayor",
  component: Apoyoconocimientogentemayor,
  argTypes: {
    
  },
} as ComponentMeta<typeof Apoyoconocimientogentemayor>;

const Template: ComponentStory<typeof Apoyoconocimientogentemayor> = (args: any) => (
    <OverlaySwapProvider>
        <Apoyoconocimientogentemayor {...args} />
    </OverlaySwapProvider>
);

export const ApoyoconocimientogentemayorTemplate = Template.bind({});

ApoyoconocimientogentemayorTemplate.args = {};