export default Loading;
declare function Loading(): React.JSX.Element;
import React from "react";
