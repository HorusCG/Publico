export default Rectanglefour;
declare function Rectanglefour(props: any): React.JSX.Element;
declare namespace Rectanglefour {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const Rectanglefour0: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorrido0: PropTypes.Requireable<any>;
        const RectanglefouronClick: PropTypes.Requireable<any>;
        const RectanglefouronMouseEnter: PropTypes.Requireable<any>;
        const RectanglefouronMouseOver: PropTypes.Requireable<any>;
        const RectanglefouronKeyPress: PropTypes.Requireable<any>;
        const RectanglefouronDrag: PropTypes.Requireable<any>;
        const RectanglefouronMouseLeave: PropTypes.Requireable<any>;
        const RectanglefouronMouseUp: PropTypes.Requireable<any>;
        const RectanglefouronMouseDown: PropTypes.Requireable<any>;
        const RectanglefouronKeyDown: PropTypes.Requireable<any>;
        const RectanglefouronChange: PropTypes.Requireable<any>;
        const Rectanglefourondelay: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonClick: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseEnter: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseOver: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonKeyPress: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonDrag: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseLeave: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseUp: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonMouseDown: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonKeyDown: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoonChange: PropTypes.Requireable<any>;
        const HolaminombreesErickyyosertuasesorduranteesterecorridoondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
