export function ConditionElementWithRol({ rolsWithCondition, children }: {
    rolsWithCondition: any;
    children: any;
}): React.JSX.Element;
import React from "react";
