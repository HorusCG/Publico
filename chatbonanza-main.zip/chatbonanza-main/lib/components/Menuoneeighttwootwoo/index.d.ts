export default Menuoneeighttwootwoo;
declare function Menuoneeighttwootwoo(props: any): React.JSX.Element;
declare namespace Menuoneeighttwootwoo {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezeroone0: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonClick: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonMouseEnter: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonMouseOver: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonKeyPress: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonDrag: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonMouseLeave: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonMouseUp: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonMouseDown: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonKeyDown: PropTypes.Requireable<any>;
        const MenuoneeighttwootwooonChange: PropTypes.Requireable<any>;
        const Menuoneeighttwootwooondelay: PropTypes.Requireable<any>;
        const FrametwootwooonClick: PropTypes.Requireable<any>;
        const FrametwootwooonMouseEnter: PropTypes.Requireable<any>;
        const FrametwootwooonMouseOver: PropTypes.Requireable<any>;
        const FrametwootwooonKeyPress: PropTypes.Requireable<any>;
        const FrametwootwooonDrag: PropTypes.Requireable<any>;
        const FrametwootwooonMouseLeave: PropTypes.Requireable<any>;
        const FrametwootwooonMouseUp: PropTypes.Requireable<any>;
        const FrametwootwooonMouseDown: PropTypes.Requireable<any>;
        const FrametwootwooonKeyDown: PropTypes.Requireable<any>;
        const FrametwootwooonChange: PropTypes.Requireable<any>;
        const Frametwootwooondelay: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonClick: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseEnter: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseOver: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyPress: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonDrag: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseLeave: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseUp: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonMouseDown: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonKeyDown: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneonChange: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivezerooneondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
