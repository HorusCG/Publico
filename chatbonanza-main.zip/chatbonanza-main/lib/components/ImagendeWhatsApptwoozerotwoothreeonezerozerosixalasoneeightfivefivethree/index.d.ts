export default ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree;
declare function ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree(props: any): React.JSX.Element;
declare namespace ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethree0: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonClick: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseEnter: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseOver: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyPress: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonDrag: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseLeave: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseUp: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonMouseDown: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonKeyDown: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeonChange: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefivethreeondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
