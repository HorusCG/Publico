import React from 'react';
declare const MainComp: ({ text, color }: {
    text: string;
    color: string;
}) => React.JSX.Element;
export default MainComp;
