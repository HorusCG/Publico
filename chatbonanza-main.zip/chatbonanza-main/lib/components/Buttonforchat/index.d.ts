export default Buttonforchat;
declare function Buttonforchat(props: any): React.JSX.Element;
declare namespace Buttonforchat {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveone0: PropTypes.Requireable<any>;
        const ButtonforchatonClick: PropTypes.Requireable<any>;
        const ButtonforchatonMouseEnter: PropTypes.Requireable<any>;
        const ButtonforchatonMouseOver: PropTypes.Requireable<any>;
        const ButtonforchatonKeyPress: PropTypes.Requireable<any>;
        const ButtonforchatonDrag: PropTypes.Requireable<any>;
        const ButtonforchatonMouseLeave: PropTypes.Requireable<any>;
        const ButtonforchatonMouseUp: PropTypes.Requireable<any>;
        const ButtonforchatonMouseDown: PropTypes.Requireable<any>;
        const ButtonforchatonKeyDown: PropTypes.Requireable<any>;
        const ButtonforchatonChange: PropTypes.Requireable<any>;
        const Buttonforchatondelay: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonClick: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseEnter: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseOver: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyPress: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonDrag: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseLeave: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseUp: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonMouseDown: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonKeyDown: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneonChange: PropTypes.Requireable<any>;
        const ImagendeWhatsApptwoozerotwoothreeonezerozerosixalasoneeightfivefiveoneondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
