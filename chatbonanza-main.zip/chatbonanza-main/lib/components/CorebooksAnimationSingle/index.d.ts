export default CorebooksAnimationSingle;
declare function CorebooksAnimationSingle(props: any): React.JSX.Element;
import React from "react";
