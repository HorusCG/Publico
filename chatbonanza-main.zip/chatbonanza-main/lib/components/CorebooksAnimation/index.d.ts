export default CorebooksAnimation;
declare function CorebooksAnimation(props: any): React.JSX.Element;
import React from "react";
