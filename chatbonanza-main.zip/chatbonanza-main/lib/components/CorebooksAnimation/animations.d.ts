export type AnimationType = "INSTANT" | "MOVE_IN" | "MOVE_OUT" | "SLIDE_IN" | "SLIDE_OUT" | "PUSH" | "DISSOLVE" | "SMART_ANIMATE";
export type Direction = "LEFT" | "RIGHT" | "TOP" | "BOTTOM";
export declare const getAnimationClass: (type: AnimationType, active: boolean, single: boolean, direction?: Direction) => string;
