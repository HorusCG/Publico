export default Registro;
declare function Registro(props: any): React.JSX.Element;
declare namespace Registro {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const RegistroonClick: PropTypes.Requireable<any>;
        const RegistroonMouseEnter: PropTypes.Requireable<any>;
        const RegistroonMouseOver: PropTypes.Requireable<any>;
        const RegistroonKeyPress: PropTypes.Requireable<any>;
        const RegistroonDrag: PropTypes.Requireable<any>;
        const RegistroonMouseLeave: PropTypes.Requireable<any>;
        const RegistroonMouseUp: PropTypes.Requireable<any>;
        const RegistroonMouseDown: PropTypes.Requireable<any>;
        const RegistroonKeyDown: PropTypes.Requireable<any>;
        const RegistroonChange: PropTypes.Requireable<any>;
        const Registroondelay: PropTypes.Requireable<any>;
        const CuadrodetextoonClick: PropTypes.Requireable<any>;
        const CuadrodetextoonMouseEnter: PropTypes.Requireable<any>;
        const CuadrodetextoonMouseOver: PropTypes.Requireable<any>;
        const CuadrodetextoonKeyPress: PropTypes.Requireable<any>;
        const CuadrodetextoonDrag: PropTypes.Requireable<any>;
        const CuadrodetextoonMouseLeave: PropTypes.Requireable<any>;
        const CuadrodetextoonMouseUp: PropTypes.Requireable<any>;
        const CuadrodetextoonMouseDown: PropTypes.Requireable<any>;
        const CuadrodetextoonKeyDown: PropTypes.Requireable<any>;
        const CuadrodetextoonChange: PropTypes.Requireable<any>;
        const Cuadrodetextoondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
