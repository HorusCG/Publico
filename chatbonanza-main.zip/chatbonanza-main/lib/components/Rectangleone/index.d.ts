export default Rectangleone;
declare function Rectangleone(props: any): React.JSX.Element;
declare namespace Rectangleone {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const Rectangleone0: PropTypes.Requireable<any>;
        const Ingresartexto0: PropTypes.Requireable<any>;
        const RectangleoneonClick: PropTypes.Requireable<any>;
        const RectangleoneonMouseEnter: PropTypes.Requireable<any>;
        const RectangleoneonMouseOver: PropTypes.Requireable<any>;
        const RectangleoneonKeyPress: PropTypes.Requireable<any>;
        const RectangleoneonDrag: PropTypes.Requireable<any>;
        const RectangleoneonMouseLeave: PropTypes.Requireable<any>;
        const RectangleoneonMouseUp: PropTypes.Requireable<any>;
        const RectangleoneonMouseDown: PropTypes.Requireable<any>;
        const RectangleoneonKeyDown: PropTypes.Requireable<any>;
        const RectangleoneonChange: PropTypes.Requireable<any>;
        const Rectangleoneondelay: PropTypes.Requireable<any>;
        const IngresartextoonClick: PropTypes.Requireable<any>;
        const IngresartextoonMouseEnter: PropTypes.Requireable<any>;
        const IngresartextoonMouseOver: PropTypes.Requireable<any>;
        const IngresartextoonKeyPress: PropTypes.Requireable<any>;
        const IngresartextoonDrag: PropTypes.Requireable<any>;
        const IngresartextoonMouseLeave: PropTypes.Requireable<any>;
        const IngresartextoonMouseUp: PropTypes.Requireable<any>;
        const IngresartextoonMouseDown: PropTypes.Requireable<any>;
        const IngresartextoonKeyDown: PropTypes.Requireable<any>;
        const IngresartextoonChange: PropTypes.Requireable<any>;
        const Ingresartextoondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
