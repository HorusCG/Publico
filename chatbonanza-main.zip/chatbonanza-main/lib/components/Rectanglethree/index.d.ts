export default Rectanglethree;
declare function Rectanglethree(props: any): React.JSX.Element;
declare namespace Rectanglethree {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const Rectanglethree0: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconocer0: PropTypes.Requireable<any>;
        const RectanglethreeonClick: PropTypes.Requireable<any>;
        const RectanglethreeonMouseEnter: PropTypes.Requireable<any>;
        const RectanglethreeonMouseOver: PropTypes.Requireable<any>;
        const RectanglethreeonKeyPress: PropTypes.Requireable<any>;
        const RectanglethreeonDrag: PropTypes.Requireable<any>;
        const RectanglethreeonMouseLeave: PropTypes.Requireable<any>;
        const RectanglethreeonMouseUp: PropTypes.Requireable<any>;
        const RectanglethreeonMouseDown: PropTypes.Requireable<any>;
        const RectanglethreeonKeyDown: PropTypes.Requireable<any>;
        const RectanglethreeonChange: PropTypes.Requireable<any>;
        const Rectanglethreeondelay: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronClick: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronMouseEnter: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronMouseOver: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronKeyPress: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronDrag: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronMouseLeave: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronMouseUp: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronMouseDown: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronKeyDown: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconoceronChange: PropTypes.Requireable<any>;
        const TepuedobrindarconocimientosQutemategustariaconocerondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
