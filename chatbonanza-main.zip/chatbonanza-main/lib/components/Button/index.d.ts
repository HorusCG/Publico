export default Button;
declare function Button(props: any): React.JSX.Element;
declare namespace Button {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const Oneeighttwootwoo0: PropTypes.Requireable<any>;
        const ButtononClick: PropTypes.Requireable<any>;
        const ButtononMouseEnter: PropTypes.Requireable<any>;
        const ButtononMouseOver: PropTypes.Requireable<any>;
        const ButtononKeyPress: PropTypes.Requireable<any>;
        const ButtononDrag: PropTypes.Requireable<any>;
        const ButtononMouseLeave: PropTypes.Requireable<any>;
        const ButtononMouseUp: PropTypes.Requireable<any>;
        const ButtononMouseDown: PropTypes.Requireable<any>;
        const ButtononKeyDown: PropTypes.Requireable<any>;
        const ButtononChange: PropTypes.Requireable<any>;
        const Buttonondelay: PropTypes.Requireable<any>;
        const OneeighttwootwooonClick: PropTypes.Requireable<any>;
        const OneeighttwootwooonMouseEnter: PropTypes.Requireable<any>;
        const OneeighttwootwooonMouseOver: PropTypes.Requireable<any>;
        const OneeighttwootwooonKeyPress: PropTypes.Requireable<any>;
        const OneeighttwootwooonDrag: PropTypes.Requireable<any>;
        const OneeighttwootwooonMouseLeave: PropTypes.Requireable<any>;
        const OneeighttwootwooonMouseUp: PropTypes.Requireable<any>;
        const OneeighttwootwooonMouseDown: PropTypes.Requireable<any>;
        const OneeighttwootwooonKeyDown: PropTypes.Requireable<any>;
        const OneeighttwootwooonChange: PropTypes.Requireable<any>;
        const Oneeighttwootwooondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
