export default Segurosaludviejito;
declare function Segurosaludviejito(props: any): React.JSX.Element;
declare namespace Segurosaludviejito {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const SegurosaludviejitoonClick: PropTypes.Requireable<any>;
        const SegurosaludviejitoonMouseEnter: PropTypes.Requireable<any>;
        const SegurosaludviejitoonMouseOver: PropTypes.Requireable<any>;
        const SegurosaludviejitoonKeyPress: PropTypes.Requireable<any>;
        const SegurosaludviejitoonDrag: PropTypes.Requireable<any>;
        const SegurosaludviejitoonMouseLeave: PropTypes.Requireable<any>;
        const SegurosaludviejitoonMouseUp: PropTypes.Requireable<any>;
        const SegurosaludviejitoonMouseDown: PropTypes.Requireable<any>;
        const SegurosaludviejitoonKeyDown: PropTypes.Requireable<any>;
        const SegurosaludviejitoonChange: PropTypes.Requireable<any>;
        const Segurosaludviejitoondelay: PropTypes.Requireable<any>;
        const FramesixonClick: PropTypes.Requireable<any>;
        const FramesixonMouseEnter: PropTypes.Requireable<any>;
        const FramesixonMouseOver: PropTypes.Requireable<any>;
        const FramesixonKeyPress: PropTypes.Requireable<any>;
        const FramesixonDrag: PropTypes.Requireable<any>;
        const FramesixonMouseLeave: PropTypes.Requireable<any>;
        const FramesixonMouseUp: PropTypes.Requireable<any>;
        const FramesixonMouseDown: PropTypes.Requireable<any>;
        const FramesixonKeyDown: PropTypes.Requireable<any>;
        const FramesixonChange: PropTypes.Requireable<any>;
        const Framesixondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
