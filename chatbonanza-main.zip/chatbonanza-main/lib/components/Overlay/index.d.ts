export default Overlay;
/**
 *
 * @param  Components: List<{Component: React.Element, props: Object, selectedName: string}>
 * @param  selectedName: string
 * @param  onClickBack: event
 * @returns
 */
declare function Overlay({ children, Components, selectedName, onClickBack }: {
    children: any;
    Components: any;
    selectedName: any;
    onClickBack: any;
}): React.JSX.Element | null;
import React from "react";
