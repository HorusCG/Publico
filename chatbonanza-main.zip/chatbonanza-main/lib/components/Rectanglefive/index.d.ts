export default Rectanglefive;
declare function Rectanglefive(props: any): React.JSX.Element;
declare namespace Rectanglefive {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const Rectanglefive0: PropTypes.Requireable<any>;
        const Ingresatuedad0: PropTypes.Requireable<any>;
        const RectanglefiveonClick: PropTypes.Requireable<any>;
        const RectanglefiveonMouseEnter: PropTypes.Requireable<any>;
        const RectanglefiveonMouseOver: PropTypes.Requireable<any>;
        const RectanglefiveonKeyPress: PropTypes.Requireable<any>;
        const RectanglefiveonDrag: PropTypes.Requireable<any>;
        const RectanglefiveonMouseLeave: PropTypes.Requireable<any>;
        const RectanglefiveonMouseUp: PropTypes.Requireable<any>;
        const RectanglefiveonMouseDown: PropTypes.Requireable<any>;
        const RectanglefiveonKeyDown: PropTypes.Requireable<any>;
        const RectanglefiveonChange: PropTypes.Requireable<any>;
        const Rectanglefiveondelay: PropTypes.Requireable<any>;
        const IngresatuedadonClick: PropTypes.Requireable<any>;
        const IngresatuedadonMouseEnter: PropTypes.Requireable<any>;
        const IngresatuedadonMouseOver: PropTypes.Requireable<any>;
        const IngresatuedadonKeyPress: PropTypes.Requireable<any>;
        const IngresatuedadonDrag: PropTypes.Requireable<any>;
        const IngresatuedadonMouseLeave: PropTypes.Requireable<any>;
        const IngresatuedadonMouseUp: PropTypes.Requireable<any>;
        const IngresatuedadonMouseDown: PropTypes.Requireable<any>;
        const IngresatuedadonKeyDown: PropTypes.Requireable<any>;
        const IngresatuedadonChange: PropTypes.Requireable<any>;
        const Ingresatuedadondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
