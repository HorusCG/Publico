export default Rectangletwoo;
declare function Rectangletwoo(props: any): React.JSX.Element;
declare namespace Rectangletwoo {
    namespace propTypes {
        const style: PropTypes.Requireable<any>;
        const Rectangletwoo0: PropTypes.Requireable<any>;
        const Ingresartexto0: PropTypes.Requireable<any>;
        const RectangletwooonClick: PropTypes.Requireable<any>;
        const RectangletwooonMouseEnter: PropTypes.Requireable<any>;
        const RectangletwooonMouseOver: PropTypes.Requireable<any>;
        const RectangletwooonKeyPress: PropTypes.Requireable<any>;
        const RectangletwooonDrag: PropTypes.Requireable<any>;
        const RectangletwooonMouseLeave: PropTypes.Requireable<any>;
        const RectangletwooonMouseUp: PropTypes.Requireable<any>;
        const RectangletwooonMouseDown: PropTypes.Requireable<any>;
        const RectangletwooonKeyDown: PropTypes.Requireable<any>;
        const RectangletwooonChange: PropTypes.Requireable<any>;
        const Rectangletwooondelay: PropTypes.Requireable<any>;
        const IngresartextoonClick: PropTypes.Requireable<any>;
        const IngresartextoonMouseEnter: PropTypes.Requireable<any>;
        const IngresartextoonMouseOver: PropTypes.Requireable<any>;
        const IngresartextoonKeyPress: PropTypes.Requireable<any>;
        const IngresartextoonDrag: PropTypes.Requireable<any>;
        const IngresartextoonMouseLeave: PropTypes.Requireable<any>;
        const IngresartextoonMouseUp: PropTypes.Requireable<any>;
        const IngresartextoonMouseDown: PropTypes.Requireable<any>;
        const IngresartextoonKeyDown: PropTypes.Requireable<any>;
        const IngresartextoonChange: PropTypes.Requireable<any>;
        const Ingresartextoondelay: PropTypes.Requireable<any>;
    }
}
import React from "react";
import PropTypes from "prop-types";
