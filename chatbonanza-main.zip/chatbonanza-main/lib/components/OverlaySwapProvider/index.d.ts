export const OverlaySwapContext: React.Context<any>;
export default OverlaySwapProvider;
import React from "react";
declare function OverlaySwapProvider({ children }: {
    children: any;
}): React.JSX.Element;
